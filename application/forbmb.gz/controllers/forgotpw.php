<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ForgotPW extends CI_Controller {
	
	function index()
	{
		$this->load->view('forgotpw');
	}
	
	function verify()
	{
		$this->load->model('coreapp/user_model');
		$this->load->library('shortxml');
		$this->load->library('session');
		
		$xml = $this->shortxml;
		$session = $this->session;
		
		$userID = $this->input->post('forgottenID', TRUE);
		$result = $this->user_model->getUserQuestion($userID);
		
		if ($result->num_rows() > 0) {
			$row = $result->row_array();
			$xml->setXML($row['xml2']. $row['grpxml']);
			
			if ($xml->getValue('WEBSTAT') !== '2') {
				echo json_encode(array(
					'verified' => FALSE,
					'message' => 'User ID not yet activated'
				));
				exit();
			}
			
			$question = $xml->getValue('WEBQSTN');
			$answer = $xml->getValue('WEBANS');
			$minChar = $xml->getValue('MINCHAR');
			
			//save userID and secretAnswer to cache
			//session_start();
			//$_SESSION['secretAnswer'] = $answer;
			//$_SESSION['userID'] = $userID;
			//$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
			//$this->cache->save($this->core->getSessionID() .'secretAnswer', $answer, CACHE_TTL);
			//$this->cache->save($this->core->getSessionID() .'userID', $userID, CACHE_TTL);
			$session->unset_userdata(array(
				'secretAnswer',
				'userID'
			));
			$session->set_userdata(array(
				'secretAnswer' => $answer,
				'userID' => $userID
			));
			
			
			echo json_encode(array(
				'verified' => TRUE,
				'question' => $question,
				'minchar'  => $minChar
			));
		} else {
			echo json_encode(array(
				'verified' => FALSE,
				'message' => 'Invalid User ID'
			));
		}
	}
	
	function submit()
	{
		//$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coreapp/user_model');
		$this->load->library('session');
		
		$session = $this->session;
		//if ($secretAnswer = $this->cache->get($this->core->getSessionID() . 'secretAnswer')) {
		if ($secretAnswer = $session->userdata('secretAnswer')) {
			$this->load->library('core');
			
			$userID = $session->userdata('userID');
			
			$answer = $this->core->encrypt($userID, $this->input->post('secretAnswer', TRUE));
			if ($secretAnswer === $answer) {
				$newPassword = $this->core->encrypt($userID, $this->input->post('newPassword', TRUE));
				$question = $this->input->post('secretQuestion', TRUE);
				$answer = $this->core->encrypt($userID, $this->input->post('secretAnswer', TRUE));
				
				$result = $this->user_model->setForgotPass($userID, $newPassword, $question, $answer);
				
				if ($result->num_rows() > 0) {
					$row = $result->row_array();
					
					//$this->cache->clean();
					$success = TRUE;
					$message = $row['errmsg'];
				} else {
					$success = FALSE;
					$message = 'An error has occured';
				}	
			} else {
				$success = FALSE;
				$message = 'Wrong answer';
			}
		} else {
			$success = FALSE;
			$message = 'Cache has expired';
		}
		
		$session->unset_userdata(array(
			'secretAnswer',
			'userID'
		));
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
}