<div id="transactionMonitoring" class="constrained">
    <h1>Transaction Monitoring</h1>
    <table class="dataTable">
        <thead>
            <tr>
                <th>Time</th>
                <th>Log Key</th>
                <th>Trace No.</th>
                <th>Sequence No.</th>
                <th>Trx Code</th>
                <th>Mnemonic</th>
                <th>Message Type</th>
                <th>Terminal</th>
                <th>Authorizer</th>
                <th>Void Code</th>
                <th>Void Description</th>
                <th>Product Key 1</th>
                <th>Amt. Req.</th>
                <th>Amt. Auth</th>
                <th>Terminal ID</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<div id="bottom">
    <span class="buttons floatRight">
    	<button id="refreshBtn">Refresh</button
        ><button class="closebtn">Close</button>
    </span>
</div>
<div id="customToolbar" class="hidden">
    <div class="top">
        <!--<div class="dataTables_custom floatLeft"><span class="info"></span></div>-->
        <div class="dataTables_custom floatLeft" style="margin: 4px 0 0 50px">
        		<label for="dtLog">Date:</label>
        		<input type="text" id="dtLog" style="width:80px" maxlength="10" value="<?php echo $date; ?>" class="datePicker" readonly/>
        	<span class="info">
            	<span class="label">Rate:</span><span id="rate">0</span> tps
			</span>
            <span class="info">
            	<span class="label">Transactions for the day:</span><span id="counter">0</span>
			</span>
		</div>
    </div>
    <div class="bottom">
        <div class="dataTables_custom floatLeft" style="margin: 5px 0 0 50px">
            <span class="info">
                <input id="cboCmd" type="checkbox"/>
                <label for="cboCmd">include ATM commands / unsolicited status</label>
            </span>
            <span class="info">
                <input type="checkbox" id="autoRefresh"/>
                <label for="autoRefresh">Refresh every </label><input type="number" id="secs" style="width:30px" class="numbersOnly" step="1" min="5" max="99" value="5" disabled><label for="autoRefresh"> secs.</label>
            </span>
		</div>
    </div>
</div>
<style>
.dataTables_scrollBody {
	min-height:300px !important;
	max-height:400px !important;
}
input[type="checkbox"] {
	position:relative;
	top:2px;
}
input[step] {
	font-size:11px;
	padding:2px;
}
</style>
<script>
$(function () {
	//init vars
	var counter = '#counter',
        rate = '#rate',
        cboCmd = '#cboCmd',
		autoRefresh = '#autoRefresh',
		refTimer = '#secs',
        cmd = 0,
        trx = 0,
        tps = 0.00;
		
	vCodes = <?php echo html_entity_decode($vCodes); ?>;
	//end
	
    oTable = $(DATATABLE).dataTable({
        bRetrieve: true,
        bJQueryUI: true,
        iDisplayLength: 25,
		aLengthMenu: [
			[25, 50, 100, 200, 500, 1000], [25, 50, 100, 200, 500, 1000] // -1 = 'All'
		],
        aaSorting: [],
		aoColumns: [
			null, //time
			{ sClass: 'centerAlign' }, //log key
			null, //trace no
			null, //sequence no
			{ sClass: 'centerAlign' }, //trx code
			null, //mnemonic
			null, //msg type
			{ sClass: 'centerAlign' }, //terminal
			{ sClass: 'centerAlign' }, //authorizer
			{ sClass: 'centerAlign' }, //vcode
			null, //vdesc
			null, //product key 1
			{ sClass: 'rightAlign' }, //amt req
			{ sClass: 'rightAlign' }, //amt ath
			null //terminal ID
		],
        sScrollY: '100%',
        sScrollX: '100%',
        sPaginationType: 'full_numbers',
		fnInitComplete: function () {
			getData();
		},
		fnRowCallback: function(nRow, aData, iDisplayIndex) {
			//apply row colors
			var msgDesc = aData[6];
			var msgType = parseInt(msgDesc.substring(0, msgDesc.indexOf(':')));
			var vCode = parseInt(aData[9]);
			var rowColor = getRowColor(msgType, vCode);
			$(nRow).addClass(rowColor);
			//end
			return nRow;
		}
    });
    $.fn.dataTableExt.iApiIndex = 0;

	//display Rate and Transactions for the day
	$('.ui-toolbar:first').append($('#customToolbar .top').html());
    $('.ui-toolbar:last').append($('#customToolbar .bottom').html());
		
	$(DTPICKER).datepicker({
		changeMonth: true,
        changeYear: true,
		maxDate: '+0d',
        yearRange: '-10y:-0y'
	});
		
    $('#refreshBtn').click(getData);
	
	$('.dataTables_length select').change(getData);
	
	$(cboCmd + ',#dtLog').change(getData);
    /*$('#report').click(function () {
        window.open('monitoring/transactions_report')
    })*/
	
	$(autoRefresh + ',' + refTimer).change(function() {
		var timer = $('#secs');
		clearInterval(ref);
		if ($(autoRefresh).attr('checked')) {
			timer.removeAttr('disabled');
			getData();
			ref = setInterval(function () {
				getData();
			}, timer.val() * 1000);
		} else {
			timer.attr('disabled', true);
			clearInterval(ref);
		}
	});
	
	function getTPS(a, b, c) {
		if (a === b) {
			return 0;
		} else {
			var d = a.substr(0, 2);
			var e = a.substr(3, 2);
			var f = a.substr(6);
			var g = b.substr(0, 2);
			var h = b.substr(3, 2);
			var i = b.substr(6);
			var j = new Date(0, 0, 0, d, e, f, 0);
			var k = new Date(0, 0, 0, g, h, i, 0);
			var l = j.getTime() - k.getTime();
			var m = l / 1000;
			var n = c / m;
			n = parseFloat(Math.round(n * Math.pow(10, 2)) / Math.pow(10, 2));
			return n
		}
	}
	
	function getData() {
		var cmd = $(cboCmd).is(':checked') === true ? '1' : '0';
		var dtlog = $('#dtLog').val();
        var limit = $('.dataTables_length select option:selected').text();

        requests.push(
			$.ajax({
				url: 'monitoring/transactions/getdata',
				type: 'POST',
				cache: false,
				data: {
					cmd: cmd,
					dtlog: dtlog,
					limit: limit
				},
				dataType: 'json',
				beforeSend: function () {
					abortAJAXRequests();
					waitMessage('Retrieving transaction log...');
				},
				error: function (a, b, c) {
					//if not aborted
					if (a.status !== 0) {
						messageBox('An error has occured: ' + a.status + ' ' + a.statusText, 'Error');
					}
					if ($(cboCmd).attr('checked') === true) {
						$(cboCmd).removeAttr('checked')
					} else {
						$(cboCmd).attr('checked', 'checked')
					}
				},
				success: function (data) {
					$(MSGBOX).dialog('close');
					
					if (data.success === true) {
						oTable.fnClearTable(0);
						oTable.fnAddData(data.details);
						oTable.fnDraw();
	
						var tfd = data.count; //transactions for the day
						
						var lastRow = oTable.fnSettings().fnRecordsDisplay() -1;
						
						var startTime = oTable.fnGetData(0)[0];
						var endTime = oTable.fnGetData(lastRow)[0];
						
						var tps = getTPS(startTime, endTime, tfd);
						$(counter).text(tfd);
						$(rate).text(tps);
					} else {
						oTable.fnClearTable(0);
						oTable.fnDraw();
						$(counter).text('0');
						$(rate).text('0');
					}
					
				},
				complete: function () {}
			})
		)
	}
});
</script>