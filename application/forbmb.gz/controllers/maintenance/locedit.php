<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class LocEdit extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->load->model('coresys/misc_model');
		$this->core->checkUserAllows(LOCATION_NO);
	}
	
	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		$core = $this->core;
		
		//$this->cache->clean();
		if (!$location = $this->cache->get($this->core->getSessionID() . 'location')) {
			$this->load->helper('url');
			redirect('welcome');
			exit();
		}
		
		$result = NULL;
		
		if (!$locTypes = $this->cache->get($this->core->getSessionID() . 'locTypes')) {			
			$result = $this->misc_model->getLocationTypes();
			$locTypes = $result->result_array();
			
			$result->free_result();
			$result->next_result();
			$this->cache->save($this->core->getSessionID() .'locTypes', $locTypes, CACHE_TTL);
		}
		
		$data['locationtType'] = NULL;
		if (count($locTypes) > 0) {
			foreach ($locTypes as $row) {
				$selected = $row['codevalue'] === $location['locType'] ? ' selected' : NULL;
				$data['locationtType'] .= '<option value="'. $row['codeseqno'] .'"'. $selected .'>'. $row['codevalue'] .'</option>';
			}
		} else {
			$data['locationtType'] .= '<option value="">No Location Types Defined</option>';
		}
		
		$data['brname'] = $this->core->getBranchName();
		
		$data['title'] = 'Edit Location';
		$data['submitBtnMsg'] = 'Update location?';
		$data['formAction'] = 'maintenance/locedit/submit';
		$data['hiddenInput'] = '<input type="hidden" name="locCode" value="'. $location['locCode'] .'"/>';
		$data['location'] = $location['locName'];
		
		if ($core->isHeadOffice()) {
			$this->load->model('coreapp/area_model');
			
			//get selected			
			$result = $this->area_model->getAreaByBranch($location['brCode']);
			
			if ($result->num_rows() > 0) {
				$row = $result->row_array();
				$regionCode = $row['regioncode'];
			} else {
				$regionCode = NULL;
			}
			
			//end
			
			//area
			$result->free_result();
			$result->next_result();
			
			$result = $this->area_model->getAreaList();
			
			$data['areaInput'] = '<select name="regionCode" id="regionCode" style="width:262px">';
			if ($result->num_rows() > 0) {	
				foreach ($result->result_array() as $row) {
					$selected = $regionCode === $row['regioncode'] ? ' selected' : NULL;
					$data['areaInput'] .= '<option value="'. $row['regioncode'] .'"'. $selected .'>'. $row['areaname'] .'</option>';
				}
			} else {
				$data['areaInput'] .= '<option value="">No Area Defined</option>';
			}
			$data['areaInput'] .= '</select>';
			//end
			
			$result->free_result();
			$result->next_result();
			
			$result = $this->area_model->getBranchListByArea($regionCode);
			
			//branch
			$data['brInput'] = '<select name="brCode" id="brCode" style="width:262px" class="validate[required]">';
			if ($result->num_rows() > 0) {	
				foreach ($result->result_array() as $row) {
					//$selected = $core->getRegionCode() === $row['regioncode'] ? ' selected' : NULL;
					$data['brInput'] .= '<option value="'. $row['brcode'] .'">'. $row['brname'] .'</option>';
				}
			} else {
				$data['brInput'] .= '<option value="">No Branch Defined</option>';
			}
			$data['brInput'] .= '</select>';
			//end
			
		} else {
			$data['areaInput'] = '<input type="text" id="areaName" style="width:250px" value="'. $core->getAreaName() .'" readonly/>';
			$data['brInput'] = '<input type="text" name="brCode" id="brCode" style="width:250px" value="'. $core->getBranchName() .'" readonly/>';
		}
		
		$this->load->view('maintenance/location', $data);
	}
	
	function submit()
	{
		$this->load->model('coreapp/user_model');
			
		$row = $this
			->user_model
			->checkLogin(
				$this->core->getUserID(),
				$this->core->getSessionID()
			)
			->row_array();
		
		if ($row['errno'] !== '8') { //if session valid
			$isEdited = intval($this->input->post('isEdited', TRUE)) === 0 ? FALSE : TRUE;
		
			$result = $this->misc_model->updateLocation(
				$this->input->post('locCode', TRUE),
				$this->input->post('location', TRUE),
				$this->input->post('brCode', TRUE),
				$this->input->post('locationtype', TRUE),
				$isEdited
			);
			
			$row = $result->row_array();
			
			if ($row['errno'] > 0) {
				$success = FALSE;
				$message = $row['errmsg'];
			} else {
				$success = TRUE;
				$message = 'Location updated successfully';
			}
		} else {
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message,
			'errorno' => $row['errno']
		));
	}
}