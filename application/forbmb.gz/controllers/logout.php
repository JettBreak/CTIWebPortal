<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logout extends CI_Controller {
	
	function index()
	{
		$this->load->model('coreapp/user_model');
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		$this->load->library('session');
		$this->load->library('core');
		$this->load->helper('file');
		
		$cache 	 = $this->cache;
		$user	 = $this->user_model;
		$session = $this->session;
		$core	 = $this->core;
		
		$userID  = $core->getUserID();
		$grpseqno = $core->getUserGroup();
		
		$user->userLogOut($userID, $grpseqno);
		$session->sess_destroy();
				
		$this->db1 = $this->load->database(DB1, TRUE);
		$this->db1->cache_delete_all();
		$this->db2 = $this->load->database(DB2, TRUE);
		$this->db2->cache_delete_all();
		
		$cache->clean();	
		//clear site temp files
		$inst = $_SESSION['inst'];
		
		$data['folder']	= $inst['css'];
		$data['bankName'] = $inst['bankName'];
		$data['siteURL'] = $inst['siteURL'];
		
		//destroy session but retain inst info
		session_destroy();
		session_start();
		
		$_SESSION['inst'] = $inst;
		//
		
		delete_files(TEMP_PATH);
		$this->load->view('login', $data);
	}
}
/* End of file logout.php */
/* Location: ./application/controllers/logout.php */