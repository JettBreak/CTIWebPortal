<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class POS_model extends CI_Model {
	private $db, $security;
	
	function POS_model()
	{
		$this->db = $this->load->database(DB2, TRUE);
		$this->security = $this->coresecurity;
		//sets the current database
		$this->security->_initDb($this->db);
	}
	//termType
	function getTerminalLocations()
	{
		$query = "SELECT a.loccode, b.location, b.brcode FROM termlist a LEFT JOIN location b ON (a.loccode = b.loccode) WHERE a.termtype = ? GROUP BY loccode ORDER BY b.brcode";
		return $this->db->query($query, func_get_args());
	}
	function getAllLocations()
	{
		$query = "CALL sp_getalllocations()";	
		return $this->db->query($query);
	}
	//$branchCode, $loccode, $status
	function getPOSList()
	{	
		$query = "CALL sp_getposlist(?,?,?)";	
		return $this->db->query($query, func_get_args());
	}
	
	function getPOSStatus()
	{				
		$query = "CALL sp_getposstatus";
		return $this->db->query($query);
	}
	//$terminalCode
	function getPOSJournal()
	{		
		$query = "CALL sp_getterminaljournal('POS',?)";
		return $this->db->query($query, func_get_args());
	}
	//$terminalCode
	function getPOSTransactionHistory()
	{		
		$query = "CALL sp_getpostranhistory(?)";
		return $this->db->query($query, func_get_args());
	}
	
	function getMessageTypes()
	{	
		$query = "CALL sp_getmessagetypelist";	
		return $this->db->query($query);
	}
	
	function getTransactionList()
	{	
		$query = "CALL sp_gettransactionlist";
		return $this->db->query($query);
	}
	
	function getVoidCodeList()
	{	
		$query = "CALL sp_getvoidcodelist";
		return $this->db->query($query);
	}
	
	//Maintenance Form 
	
	function getPOSLanguage()
	{
		$query = "CALL sp_getposlanguage";
		return $this->db->query($query);
	}
	//$branchCode
	function getLocations()
	{
		$query = "CALL sp_getlocations(?)";
		return $this->db->query($query, func_get_args());
	}
	//$termCode
	function getPOSInfo()
	{
		$query = "CALL sp_getposinfo(?)";
		return $this->db->query($query, func_get_args());
	}
	//$termCode, $termID, $luno, $locCode, $desc, $progCode
	function insertPOSTerminal()
	{
		$query = "CALL sp_insertposterminal(?,?,?,?,?,?)";
		return $this->db->query($query, func_get_args());
	}
	//$termCode, $termID, $luno, $locCode, $desc, $progCode
	function updatePOSTerminal()
	{
		$query = "CALL sp_updateposterminal(?,?,?,?,?,?)";
		return $this->db->query($query, func_get_args());
	}
	//$termCode
	function deletePOSTerminal()
	{
		$query = "CALL sp_deleteposterminal(?)";
		return $this->db->query($query, func_get_args());
	}
}