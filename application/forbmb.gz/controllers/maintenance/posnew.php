<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class POSNew extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(MAINTENANCEPOS_NO);
	}

	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coresys/pos_model');
		$this->load->model('coreapp/area_model');
		
		$cache = $this->cache;
		$pos = $this->pos_model;
		$core = $this->core;
		
		$data['luno'] = NULL;
		$data['status'] = 'Out of Service';
				
		//get POS language from cache
		if (!$posLang = $cache->get($this->core->getSessionID() . 'posLang')) {		
			$result = $pos->getPOSLanguage();
			$posLang = $result->result_array();
			
			$result->free_result();
			$result->next_result();
		
			$cache->save($this->core->getSessionID() . 'posLang', $posLang, CACHE_TTL);
		}
		
		$data['posLang'] = NULL;
		foreach ($posLang as $row) {
			$data['posLang'] .= '<option value="'. $row['termlang'] .'">'. $row['description'] .'</option>';
		}
		//end
		
		//location
		if ($core->isHeadOffice()) {
			$result = $pos->getAllLocations();
		} else {
			$result = $pos->getLocations($core->getBranchCode());
		}
		$resultArr = $result->result_array();
		
		$result->free_result();
		$result->next_result();
		
		$data['location'] = NULL;
		
		$areaName = 'Unknown';
		$brchName = 'Unknown';
		
		if (count($resultArr)) {
			foreach ($resultArr as $row) {
				$result = $this->area_model->getAreaByBranch($row['brcode']);
				
				if ($result->num_rows() > 0) {
					
					$r = $result->row_array();
					
					if ($areaName === NULL) {
						$areaName = $r['areaname'];
					}
					
					if ($brchName === NULL) {
						$brchName = $r['brname'];
					}
					
					$data['location'] .= '<option value="'. $row['loccode'] .'" areaname="'. $r['areaname'] .'" brname="'. $r['brname'] .'">'. $row['location'] .'</option>';
				}
				$result->free_result();
				$result->next_result();
			}
		} else {
			$data['location'] = '<option value="">No Location Defined</option>';
		}
		//end
			
		$data['areaName'] = $areaName;
		$data['branchName'] = $brchName;
		
		$data['header'] = 'New POS Entry';
		$data['termCodeParams'] = 'class="validate[required] numbersOnly" maxlength="8"';
		$data['termID'] = NULL;
		$data['desc'] = NULL;
		$data['termIDParams'] = 'class="validate[required]"';
		$data['submitBtnVal'] = 'maintenance/posnew/submit';
		$data['waitMsg'] = 'Sending new POS entry...';
		$data['submitBtnMsg'] = 'Submit new POS entry?';
		
		$this->load->view('maintenance/posx', $data);
	}
	
	function submit()
	{
		$this->load->model('coreapp/user_model');
		
		$core  = $this->core;
		$input = $this->input;
		
		$userAudit = $core->getUserID();
		$sessionID = $core->getSessionID();
		
		$row = $this
			->user_model
			->checkLogin($userAudit, $sessionID)
			->row_array();
			
		if ($row['errno'] !== '8') { //if session valid
			$termCode = $input->post('posCode', TRUE);
			$termID   = $input->post('posID', TRUE);
			$luno	  = $input->post('luno', TRUE);
			$locCode  = $input->post('location', TRUE);
			$desc	  = $input->post('description', TRUE);
			$progLang = $input->post('progLang', TRUE);
			
			$this->load->model('coresys/pos_model');
			
			$result = $this->pos_model->insertPOSTerminal(
				$termCode, $termID, $luno, $locCode, $desc, $progLang
			);
			
			$row = $result->row_array();
			
			if ($row['errno'] === '0') {
				$success = TRUE;
				$message = 'New POS entry saved';
			} else {
				$success = FALSE;
				$message = $row['errmsg'];
			}
		} else { //if invalid userID / session then logout
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message,
			'errorno' => $row['errno']
		));
	}
}
/* End of file posnew.php */
/* Location: ./application/contollers/maintenance/posnew.php */