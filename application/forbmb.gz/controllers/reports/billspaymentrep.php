<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class BillsPaymentRep extends CI_Controller {	
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(BILLSPAYMENTREP_NO);
	}
	
	function index()
	{
		if ($this->input->get('norecord', TRUE) === 'true') {
			$data['showMsg'] = '1';
		} else {
			$data['showMsg'] = '0';
		}
		
		$data['title'] = 'BILLS PAYMENT REPORT';
		$data['date'] = date('m/d/Y');
		$data['formAction'] = 'reports/billspaymentrep/process';
		$this->load->view('reports/billspaymentrep', $data);
	}
	
	function process()
	{
		$this->load->model('coresys/reports_model');
		$this->load->library('shortxml');
		$this->load->library('zip');
		$this->load->library('pdf');
		
		$tracer = NULL;
		$core = $this->core;
		$xml = $this->shortxml;
		$pdf = $this->pdf;	
		
		
		$userName  = $core->getUserName();
		$instName  = $core->getInstName();
		$finswitch = $core->getFINSWITCH();
		$onusCode  = $core->getONUSCODE();
		
		$ISS = '';
		for ($i = 501; $i <= 519; $i++) {
			if 	($ISS !== '') {
				$ISS = $ISS . ',';
				$ISS = $ISS . $i;	
			}
		}
		
		$ckDEBUG = $this->input->post('ckDEBUG', TRUE);
		$trxDate = $this->input->post('trxDate', TRUE);
		
		$result = $this->reports_model->getTransactionForBBPRdps($core->formatDate('Y-m-d', $trxDate), $ISS, $finswitch, $onusCode);
		$stDPS = $result->result_array();
		
		$result->free_result();
		$result->next_result();
		
		$result = $this->reports_model->getTransactionForBBPRsum($core->formatDate('Y-m-d', $trxDate), $ISS, $finswitch, $onusCode);
		$stSUM = $result->result_array();
		
		$stISS = NULL; // issuer
		$stACQ = NULL; // acquirer
		$stDate = NULL; // date
		$stTime = NULL; // time
		$stTerm = NULL; // termid
		$stCard = NULL; // cardno
		$stAcct = NULL; // acctno
		$stSubN = NULL; // subname
		$stSubNo = NULL; // subscriber
		$telNo = '0000000';
		
		$stValue = '';
		$stResult = '';
		$stBBPRsum = '';
		
		$stTOTREC = 0;
		$stTOTAMT = 0;
				
		$totrec = 0;
		$totamt = 0;
		
		foreach ($stDPS as $row) {
			
			$termType = $row['termtype'];
			
			$xml->setXML($row['xml1'] . $row['xml2'] . $row['xml3'] . $row['xml4'] . $row['xml5'] . $row['xml6']);
			
			//init vars
			$stLogSeq = substr(number_format(floatval($row['logseqno']),0,'.',''),0,5);
		
			//ISS
			$stISS = $row['isscode'];
			$stISS = substr($stISS,0,4);
			$stISS = str_pad($stISS, 4, '0', STR_PAD_LEFT);
			
			//ACQ
			$stACQ = floatval($row['acqcode']);
			$stACQ = substr($stACQ,0,4);
			$stACQ = str_pad($stACQ, 4, '0', STR_PAD_LEFT);
			
			//Date
			$stDate = $core->formatDate('ymd', $row['dtlog']);
			
			//Time
			$stTime = $core->formatDate('His', $row['dtlog']);
			
			//TERM
			$stTerm = $row['termcode'];
			$stTerm = str_pad($stTerm, 8, '0', STR_PAD_LEFT);
			
			//CARD
			$stCard = trim(substr($row['prkey1'],0,18));
			$stCard = str_pad($stCard, 19, '0', STR_PAD_LEFT);
			
			//ACCT
			$stAcct = $row['acct1'];
			$stAcct = str_pad($stAcct, 16, '0', STR_PAD_LEFT);
			
			//SUBName
			$stSubN = trim($xml->getValue('SUBSNAME')); // temp for inquiry
			
			if (!$stSubN) {
				$stSubN = str_pad($stSubN, 30, '0', STR_PAD_LEFT);;
			}
			
			//SUBNO
			$stSubNo = trim($xml->getValue('SUBSNO'));
			
			if (!$stSubNo) {
				$stSubNo = trim(substr($row['acct2'],0,19));
			}
			
			$stSubNo = str_pad($stSubNo, 20, '0', STR_PAD_LEFT);
			
			//INSTNo
			$stINSTNo = trim(floatval($row['instcode']));
			$stINSTNo = str_pad($stINSTNo, 3 , '0', STR_PAD_LEFT);
			
			// stMODE rules
			if($termType == 'ATM' && $stNode === $finswitch) {
				$stMODE = 1;	
			} elseif ($termType == 'POS') {
				$stMODE = 7;	
			} else {
				$stMODE = 2;
			}
			
			//AMTATH
			$amtath = $row['amtath'];
			$stAmtath = str_pad($amtath, 12 , '0', STR_PAD_LEFT);
			
			//TOTAMT
			$totamt = $totamt + $amtath;
			
			if ($termType === $finswitch && in_array($row['chname'], array($onusCode, 'ONUS')) ) {
					
					$stCHSEQ = substr(trim($row['tpseqno']), 0,6);
					$stCHSEQ = str_pad($stCHSEQ, 6, '0', STR_PAD_LEFT);
					//$sequenceNo = str_pad($row['tpseqno'], 6, '0', STR_PAD_LEFT);
					
			} else {
					
					$stCHSEQ = substr(trim($row['chseqno']), 0,6);
					$stCHSEQ = str_pad($stCHSEQ, 6, '0', STR_PAD_LEFT);
					
			}
			
			//$stCHSEQ = substr(trim($row['chseqno']), 0,6);
			//$stCHSEQ = str_pad($stCHSEQ, 6, '0', STR_PAD_LEFT);
			
			$stSpace = str_repeat(' ', 15);
			

			$stValue = $stISS.$stACQ.$stCHSEQ.$stDate.$stTime.$stSubNo.$stCard.$stAcct.$stAmtath.$telNo.$stINSTNo.$stSubN.$stMODE.$stTerm.$stSpace."\r\n";
			//$stValue = $stISS.'|'.$stACQ.'|('.$stCHSEQ.')|'.$stDate.'|'.$stTime.'|'.$stSubNo.'|'.$stCard.'|'.$stAcct.'|'.$stAmtath.'|'.$telNo.'|'.$stINSTNo.'|'.$stSubN.'|'.$stMODE.'|'.$stTerm.'|'.$stSpace."\r\n";
			
			
			$stTran = substr(trim($row['mnemonic']), 0, 8);
				$stResult .= $stValue;
			if ($stTran !== 'ERR') {
					
			}
			
			$totrec += 1;			
			
		}
		
		$stTOTREC = str_pad($totrec, 16, '0', STR_PAD_LEFT); 
		$stTOTAMT = str_pad($totamt, 12, '0', STR_PAD_LEFT);
		
		$stResult .= '9999'.str_repeat('0', 65).$stTOTREC.$stTOTAMT.str_repeat('0', 60);
		
		$totamt = 0;
		$totctr = 0;
		$totrec = 0;
		
		foreach ($stSUM as $row) {
			
			$xml->setXML($row['xml1'] . $row['xml2'] . $row['xml3'] . $row['xml4'] . $row['xml5'] . $row['xml6']);
			
			$inst = $xml->getVALUE('INSTNAME');
			if ($inst === '') {
				
				$result->free_result();
				$result->next_result();
				
				$instcode = intval($row['instcode']);
				$result = $this->reports_model->getInstDesc($instcode);
				$r = $result->row_array();
				$inst = $r['description'];

				$result->free_result();
				$result->next_result();
			}
			
			$inst = str_pad($inst, 30, ' ', STR_PAD_RIGHT);
			
			$totctr += number_format(floatval($row['totctr']),0,'.','');
			
			$stTOT = trim(substr($row['totctr'],0,14));
			$stTOT = number_format($stTOT,0,'.',',');
			$stTOT = str_pad($stTOT, 11, ' ', STR_PAD_LEFT);
			
			$totamtDiv = $core->currency($row['totamt'] / 100);
			
			$stAMT = $totamtDiv; //number_format($totamtDiv, 2,'.',',');
			$stAMT = str_pad($stAMT, 16, ' ', STR_PAD_LEFT);
			
			$stBBPRsum .= $inst . $stTOT . $stAMT . "\r\n";
			
			$totrec += 1;
			$totamt += $row['totamt'];
			
		}
		
		$totamtDiv = $core->currency($totamt / 100);
		
		$stAMT = $totamtDiv; //number_format($totamtDiv, 2,'.',',');
		$stAMT = str_pad($stAMT, 16, ' ', STR_PAD_LEFT);
		
		$stTOT = number_format($totctr, 0,'.','');
		$stTOT = str_pad($stTOT, 11, ' ', STR_PAD_LEFT);
		
		$headerBorder = str_repeat('-', 30).' '.str_repeat('-',10).' '.str_repeat('-',15);
		
		$stBBPRsum .= $headerBorder."\r\n".str_pad("GRAND TOTAL", 30, ' ', STR_PAD_RIGHT) . $stTOT . $stAMT;
		
		$header = str_pad("INST NAME", 31, ' ', STR_PAD_RIGHT) . 
		str_pad("TOTAL TXN", 11, ' ', STR_PAD_RIGHT) . 
		str_pad("TOTAL AMT", 15, ' ', STR_PAD_RIGHT).
		"\r\n".$headerBorder;
		
		
		$suffix = $core->formatDate('mdY', $trxDate);
		
		$ext1 = '.dps';
		$ext2 = '.sum';
				
		$BBPRDPS = $stResult;
				
		$BBPRSUM = $instName. "\r\n".
				"Type = BBPR\r\n".
				"\r\n".$header."\r\n". 
				$stBBPRsum;
				
		$data = array(
			$instName . $suffix . $ext1 => $BBPRDPS,
			$instName . $suffix . $ext2 => $BBPRSUM
			
		);
		
		$this->zip->add_data($data);
		$this->zip->download('BBPR'. $suffix .'.zip'); 
		
		// set document information
		/*$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor($userName);
		$pdf->SetTitle('Approved Transactions, ACQ Per Terminal');
		$pdf->SetSubject('Card');
		$pdf->SetKeywords(NULL);
		
		// set default header data
		//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
		$pdf->SetHeaderData(NULL);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setUser($core->getUserName());
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		//set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		//set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		// ---------------------------------------------------------
		
		// Set font
		// dejavusans is a UTF-8 Unicode font, if you only need to
		// print standard ASCII chars, you can use core fonts like
		// helvetica or times to reduce file size.
		$pdf->SetFont('helvetica', '', 8.5, '', true);
		
		// Add a page
		// This method has several options, check the source code documentation for more information.
		$pdf->AddPage('L', 'Letter');
		
		$html = '<style>
			
			th {
				text-transform: uppercase;
				font-weight: bold;
				text-align: left;
			}
			</style>
			<table cellspacing="20" width="100%">
				<tr><td colspan=>
				'. $stResult .'
				</td></tr>';
		
		
		$pdf->writeHTML($html, true, false, true, false, '');

		$pdf->Output('billspayment' .$dateSaveFormat . '.pdf', 'I');*/
	}
	
	/*function checkData($stTrxType, $stMsgType, $stTran)
	{
		if ( in_array($stTrxType, array('WDL', 'ADV')) ) {
			if ( in_array($stMsgType, array(51, 52)) ) {
				$stTran = 'CWD';
			}
			
			if ( in_array($stMsgType, array(71, 72, 171)) ) {
				$stTran = 'CWC';
			}
		}
		
		elseif ( in_array($stTran, array('IBFTTRCA', 'IBFTTRSA', 'TRNCASA', 'TRNSACA')) ) {
			if ( in_array($stMsgType, array(51, 52)) ) {
				$stTran = 'TFR';
			}
			
			if ( in_array($stMsgType, array(71, 72, 171)) ) {
				$stTran = 'TFC';
			}
		}
		
		elseif ( in_array($stTran, array('POSWDL', 'POSWDLSA', 'POSWDLCA')) ) {
			if ( in_array($stMsgType, array(51, 52)) ) {
				$stTran = 'SAL';
			}
			
			if ( in_array($stMsgType, array(71, 72, 171)) ) {
				$stTran = 'SLR';
			}
		}
		
		elseif ($stTrxType === 'PAY') {
			if ( in_array($stMsgType, array(51, 52)) ) {
				$stTran = 'BPS';
			}
			
			if ( in_array($stMsgType, array(71, 72, 171)) ) {
				$stTran = 'BPC';
			}
		}
		
		elseif ( in_array($stTrxType, array('IBFT', 'LOAD')) ) {
			
			if ( in_array($stTran, array('LOADSA', 'LOADCA')) ) {
				
				if ( in_array($stMsgType, array(51, 52)) ) {
					$stTran = 'ELD';
				}
				
				if ( in_array($stMsgType, array(71, 72, 171)) ) {
					$stTran = 'ELC';
				}
				
			} else {
				
				if ( in_array($stMsgType, array(71, 72, 171)) ) {
					$stTran = 'IBC';
				} else {
					$stTran = 'IBF';
				}
				
			}
			
		} else {
			$stTran = 'ERR';
		}
		
		return $stTran;
		
	}*/
}