<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Departments extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->load->model('coreapp/dept_model');
		$this->core->checkUserAllows(DEPT_NO);
	}
	
	function index()
	{
		$this->load->view('maintenance/departments');
	}
	
	function cache()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->cache->delete($this->core->getSessionID() .'department');
		
		$department = array(
			'deptCode' => $this->input->post('code', TRUE),
			'deptName' => $this->input->post('name', TRUE)
		);
		
		$success = $this->cache->save($this->core->getSessionID() .'department', $department, CACHE_TTL);
		
		echo json_encode(array(
			'success' => $success
		));
	}
	
	function getData()
	{
		$result = $this->dept_model->getDepartments();
		
		$details = array();
		foreach ($result->result_array() as $row) {			
			$details[] = array(
				$row['codeseqno'],
				$row['codevalue']
			);
		}
		
		echo json_encode(array(
			'success' => TRUE,
			'details' => $details
		));
	}
	
	function delete()
	{	
		$result = $this->dept_model->deleteDepartment(
			$this->input->post('deptCode', TRUE),
			$this->core->getBranchID(),
			$this->core->getIPAddress(),
			$this->core->getWorkstation(),
			$this->core->getUserID(),
			$this->core->getSessionID()
		);
		
		$row = $result->row_array();
		
		if ($row['errno'] > 0) {
			$success = FALSE;
		} else {
			$success = TRUE;
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $row['errmsg'],
			'errorno' => $row['errno']
		));
	}
}