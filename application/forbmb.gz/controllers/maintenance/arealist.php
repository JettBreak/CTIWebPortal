<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Arealist extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->load->model('coreapp/area_model');
		$this->core->checkUserAllows(AREA_NO);
	}
	
	function index()
	{
		$this->load->view('maintenance/arealist');
	}
	
	/*function cache()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->cache->delete($this->core->getSessionID() .'areaList');
		
		$area = array(
			'areaCode' => $this->input->post('code', TRUE),
			'areaName' => $this->input->post('name', TRUE) 
		);
		
		$success = $this->cache->save($this->core->getSessionID() .'areaList', $area, CACHE_TTL);
		
		echo json_encode(array(
			'success' => $success
		));
	}*/
	
	function cache()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->cache->delete($this->core->getSessionID() .'area');

		$area = array(
			'areaCode' => $this->input->post('code', TRUE),
			'areaName' => $this->input->post('name', TRUE) 
			);

		$success = $this->cache->save($this->core->getSessionID() .'area', $area, CACHE_TTL);

		echo json_encode(array(
			'success' => $success
		));
	}
	
	function getData()
	{
		//$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		$result = $this->area_model->getAreaList();
		
		$details = array();
		foreach ($result->result_array() as $row) {
			// GET DATA 
			$details[] = array(
				$row['regioncode'],
				$row['areaname']
			);
		}
		
		echo json_encode(array(
			'success' => TRUE,
			'details' => $details
		));
	}
	
	function delete()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		$areaCode = $this->input->post('areaCode', TRUE);
		$brseqno     = $this->core->getBranchID();
		$ipaddress   = $this->core->getIPAddress();
		$workstation = $this->core->getWorkstation();
		$userAudit   = $this->core->getUserID();
		$sessionID   = $this->core->getSessionID();
	 
 		$result = $this->area_model->deleteArea(
			$areaCode,
			$brseqno,
			$ipaddress,
			$workstation,
			$userAudit,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
		} else {
			$success = TRUE;
			$this->cache->delete($this->core->getSessionID() .'area');
		}
		
		$result->free_result();
		$result->next_result();
		
		echo json_encode(array(
			'success' => $success,
			'message' => $row['errmsg']/*,
			'secCode' => $secCode*/
		));
	}
}