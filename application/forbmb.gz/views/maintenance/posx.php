<form id="posForm" method="post">
    <div id="posNew">
        <h1><?php echo $header; ?></h1>
        <div id="content">
            <table width="100%">
                <tr>
                    <td width="120"><label for="posCode" class="idName">POS Code:</label></td>
                    <td width="210"><input type="text" name="posCode" id="posCode" style="width:160px" <?php echo html_entity_decode($termCodeParams); ?> autofocus/></td>
                    <td colspan="2"><span class="floatRight">All fields are required</span></td>
                </tr>
                <tr>
                    <td><label for="posID">POS ID:</label></td>
                    <td><input type="text" name="posID" id="posID" style="width:160px" class="alphaNum" maxlength="20" value="<?php echo $termID; ?>" <?php echo $termIDParams; ?>/></td>
                    <td><label for="luno">LUNO:</label></td>
                    <td><input type="text" name="luno" id="luno" style="width:70px" value="<?php echo $luno; ?>" class="validate[required] numbersOnly" maxlength="4"/></td>
                </tr>
                <tr>
                    <td><label for="description">Description:</label></td>
                    <td colspan="3"><input name="description" id="description" type="text" style="width:160px" maxlength="50" class="validate[required]" value="<?php echo $desc; ?>"/></td>
                </tr>
                <tr>
                    <td><label for="posLang">POS Language:</label></td>
                    <td colspan="3"><select name="posLang" id="posLang" style="width:172px">
                            <?php echo html_entity_decode($posLang); ?>
                        </select></td>
                </tr>
                <tr>
                    <td><label for="location">Location:</label></td>
                    <td colspan="3"><select name="location" id="location" style="width:172px" class="validate[required]">
                            <?php echo html_entity_decode($location); ?>
                        </select></td>
                </tr>
                <tr>
                    <td><label for="areaName">Area:</label></td>
                    <td colspan="3"><input type="text" name="areaName" id="areaName" style="width:160px" value="<?php echo $areaName; ?>" readonly/></td>
                </tr>
                <tr>
                    <td><label for="branchName">Branch:</label></td>
                    <td colspan="3"><input type="text" name="branchName" id="branchName" style="width:160px" value="<?php echo $branchName; ?>" readonly/></td>
                </tr>
                <tr>
                    <td><label for="statusx">Status:</label></td>
                    <td colspan="3"><input type="text" name="statusx" id="statusx" style="width:160px" value="<?php echo $status; ?>" readonly/></td>
                </tr>
            </table>
        </div>
    </div>
    <div id="bottom">
        <span class="buttons floatLeft">
            <button id="submitBtn" value="<?php echo $submitBtnVal; ?>">Submit</button
            ><button type="reset">Reset</button>
		</span><span class="buttons floatRight">
            <button id="backBtn">Back</button
            ><button class="closebtn">Close</button>
		</span>
	</div>
</form>
<script>
$(function () {
    var submitBtn = '#submitBtn',
        backBtn = '#backBtn',
        form = $('form');
		
    form.validationEngine({
        ajaxFormValidation: true,
        onBeforeAjaxFormValidation: function () {
            waitMessage('<?php echo $waitMsg; ?>')
        },
        onAjaxFormComplete: function (a, b, data, d) {
			messageBox(data.message);
			$(MSGBOX).one('dialogbeforeclose', function () {
				if (data.success === true) {
					window.location.hash = 'maintenance/pos'
				}
			});
        },
        scroll: false
    });
    form.validationEngine('attach');
	
    $(submitBtn).click(function (e) {
        e.preventDefault();
        if (form.validationEngine('validate') === true) {
            messageBox('<?php echo $submitBtnMsg; ?>', 'Warning', 'confirm', function () {
                form.submit()
            })
        }
    });
	
    $(backBtn).click(function () {
        window.location.hash = 'maintenance/pos';
        return false
    });
	
	$('#location').change(function () {
		var selected = $(this).find('option:selected');
		
		$('#areaName').val(selected.attr('areaname'));
		$('#branchName').val(selected.attr('brname'));
	});
});
</script>