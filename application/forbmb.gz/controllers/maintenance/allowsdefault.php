<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AllowsDefault extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->load->model('coreapp/allows_model');
		//$this->core->checkUserAllows(GENERALSETTINGS_NO);
	}
	
	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->library('coreconverters');
		
		//product types
		if (!$productTypes = $this->cache->get($this->core->getSessionID() . 'prTypes')) {			
			$result = $this->allows_model->getProductTypes();
			$productTypes = $result->result_array();
			
			$result->free_result();
			$result->next_result();
			
			$this->cache->save($this->core->getSessionID() .'prTypes', $productTypes, CACHE_TTL);
		}
		
		$prTypes = NULL;
		$tranAllows = NULL;
		
		if (count($productTypes) > 0) {
			foreach ($productTypes as $row) {
				$prType = $row['prtype'];
				
				$prTypes .= '<option value="'. $prType .'">'. $row['description'] .'</option>';
				
				
				//tran allows		
				$result = $this->allows_model->getDefaultTranAllows($prType);
				$visible = $tranAllows === NULL ? NULL : ';display:none"';
				$tranAllows .= '<div id="'. $prType .'" style="height:253px'. $visible .'" class="box">';
				foreach ($result->result_array() as $row) {
					//$checked = substr($allows, $row['bitno'] - 1, 1) === '1' ? ' checked' : NULL;
					$checked = NULL;
					$tranAllows .= '<input type="checkbox" id="'. $prType .'bit'. $row['bitno'] .'" name="'. $prType .'allows[]" value="'. $row['bitno'] .'"'. $checked .'/>'. $row['description'] .'<br />';
				}
				$tranAllows .= '</div>';
				
				$result->free_result();
				$result->next_result();
				//end
			}
		} else {
			$prTypes = '<option value="">No Product Types Defined</option>';
		}
		$data['prTypes'] = $prTypes;
		$data['tranAllows'] = $tranAllows;
		//end
		
		//account types
		if (!$accountTypes = $this->cache->get($this->core->getSessionID() . 'allAccountTypes')) {			
			$result = $this->allows_model->getAcctTypes();
			$accountTypes = $result->result_array();
			
			$result->free_result();
			$result->next_result();
			
			$this->cache->save($this->core->getSessionID() .'allAccountTypes', $accountTypes, CACHE_TTL);
		}
		
		$acctTypes = NULL;
		$allows = NULL;
		
		if (count($accountTypes) > 0) {
			foreach ($accountTypes as $row) {
				$groupType = $row['grouptype'];
				$val  = $row['accttype'];
				$desc = $row['description'];
				
				$visibility = $productTypes[0]['prtype'] !== $groupType ? ' style="display:none"' : NULL;
							
				$result = $this->allows_model->getDefaultAllows($groupType, $val, $groupType);
				$row = $result->row_array();
				
				if ($result->num_rows() > 0) {
					$defAllows = rtrim($this->coreconverters->asciiHexToBin($row['allows']), 0);
				} else {
					$defAllows = 0;
				}
				
				if ($allows === NULL) {
					$allows = $defAllows;
				}
				
				$result->free_result();
				$result->next_result();
				
				$acctTypes .= '<option value="'. $val .'" defaultallows="'. $defAllows .'" grouptype="'. $groupType .'"'. $visibility .'>'. $desc .'</option>';
			}
		} else {
			$acctTypes = '<option value="">No Product Types Defined</option>';
		}
		$data['acctTypes'] = $acctTypes;
		//end
		
		$this->load->view('maintenance/allowsdefault', $data);
	}
	
	function save()
	{
		$this->load->library('coreconverters');
		
		$prtype = $this->input->post('prtype', TRUE);
		$accttype = $this->input->post('accttype', TRUE);
		$allows = $this->input->post($prtype . 'allows');
		
		if ($allows) {
			$max = max($allows);
			$bin = '';
			for ($i = 1; $i <= $max; $i++) {	
				if (in_array($i, $allows)) {
					$bin .= '1';
				} else {
					$bin .= '0';
				}
			}
		} else {
			$bin = '0';
		}
		
		$hex = $this->coreconverters->asciiBinToHex($bin);
		
		$brseqno = $this->core->getBranchID();
		$ipAddress = $this->core->getIPAddress();
		$workstation = $this->core->getWorkstation();
		$userAudit = $this->core->getUserID();
		$sessionID = $this->core->getSessionID();
		
		$result = $this->allows_model->setAllowsDefault(
			$prtype,
			$prtype,
			$accttype,
			$hex,
			$hex,
			$brseqno,
			$ipAddress,
			$workstation,
			$userAudit,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
			$message = $row['errmsg'];
		} else {
			$success = TRUE;
			$message = 'Changes saved';
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
	
	function updateAll()
	{
		$this->load->library('coreconverters');
		
		$prtype = $this->input->post('prtype', TRUE);
		$accttype = $this->input->post('accttype', TRUE);
		
		$allows = $this->input->post($prtype . 'allows');
		
		if ($allows) {
			$max = max($allows);
			$bin = '';
			for ($i = 1; $i <= $max; $i++) {	
				if (in_array($i, $allows)) {
					$bin .= '1';
				} else {
					$bin .= '0';
				}
			}
		} else {
			$bin = '0';
		}
		
		$hex = $this->coreconverters->asciiBinToHex($bin);
		
		$brseqno = $this->core->getBranchID();
		$ipAddress = $this->core->getIPAddress();
		$workstation = $this->core->getWorkstation();
		$userAudit = $this->core->getUserID();
		$sessionID = $this->core->getSessionID();
		
		$result = $this->allows_model->updateAllToAllowsDefault(
			$prtype,
			$accttype,
			$hex,
			$brseqno,
			$ipAddress,
			$workstation,
			$userAudit,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
			$message = $row['errmsg'];
		} else {
			$success = TRUE;
			$message = 'Changes saved';
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
}