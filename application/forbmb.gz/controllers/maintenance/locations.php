<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Locations extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->load->model('coresys/misc_model');
		$this->core->checkUserAllows(LOCATION_NO);
	}
	
	function index()
	{
		$this->load->view('maintenance/locations');
	}
	
	function cache()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->cache->delete($this->core->getSessionID() .'location');
		
		$location = array(
			'locCode' => $this->input->post('code', TRUE),
			'locName' => $this->input->post('name', TRUE),
			'locType' => $this->input->post('type', TRUE),
			'brCode' => $this->input->post('brCode', TRUE)
		);
		
		$success = $this->cache->save($this->core->getSessionID() .'location', $location, CACHE_TTL);
		
		echo json_encode(array(
			'success' => $success
		));
	}
	
	function getBranches()
	{
		$this->load->model('coreapp/area_model');
		$regionCode = $this->input->get('regionCode', TRUE);
		
		$result = $this->area_model->getBranchListByArea($regionCode);
		
		$data = NULL;
		if ($result->num_rows() > 0) {
			foreach ($result->result_array() as $row) {
				//$selected = $core->getRegionCode() === $row['regioncode'] ? ' selected' : NULL;
				$data .= '<option value="'. $row['brcode'] .'">'. $row['brname'] .'</option>';
			}
		} else {
			$data .= '<option value="">No branch defined</option>';
		}
			
		echo $data;
	}
	
	function getData()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		if (!$locTypes = $this->cache->get($this->core->getSessionID() . 'locTypes')) {
			$result = $this->misc_model->getLocationTypes();
			$locTypes = $result->result_array();
			$this->cache->save($this->core->getSessionID() .'locTypes', $locTypes, CACHE_TTL);
			
			$result->free_result();
			$result->next_result();
		}
		
		if ($this->core->isHeadOffice()) {
			$result = $this->misc_model->getAllLocations();
		} else {
			$result = $this->misc_model->getLocations($this->core->getBranchCode());
		}
		
		$details = array();
		foreach ($result->result_array() as $row) {
			
			//get account code (TY)
			$locType = NULL;
			foreach ($locTypes as $r) {
				if ($r['codeseqno'] === $row['locsite']) {
					$locType = $r['codevalue'];
				}
			}
			//end
			
			$details[] = array(
				$row['loccode'],
				$row['location'],
				$locType,
				$row['brcode']
			);
		}
		
		echo json_encode(array(
			'success' => TRUE,
			'details' => $details
		));
	}
	
	function delete()
	{	
		$this->load->model('coreapp/user_model');
		
		$userAudit = $this->core->getUserID();
		$sessionID = $this->core->getSessionID();
		
		$row = $this
			->user_model
			->checkLogin($userAudit, $sessionID)
			->row_array();
			
		if ($row['errno'] !== '8') { //if session valid
			$locCode = $this->input->post('locCode', TRUE);
			
			$result = $this->misc_model->deleteLocation($locCode);
			
			$row = $result->row_array();
			
			if ($row['errno'] > 0) {
				$success = FALSE;
				$message = $row['errmsg'];
			} else {
				$success = TRUE;
				$message = 'Success';
			}
		} else {
			$success = FALSE;
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $row['errmsg'],
			'errorno' => $row['errno']
		));
	}
}