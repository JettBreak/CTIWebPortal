<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transactions extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(MONTRANS_NO);
	}
	
    function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		//get void codes
		if (!$vCodes = $this->cache->get($this->core->getSessionID() . 'vCodes')) {
			$this->load->model('coresys/atm_model');
			$result = $this->atm_model->getVoidCodes();
			
			$vCodes = NULL;
			foreach ($result->result_array() as $row) {
				$vCodes[] = intval($row['codevalue']);
			}
			
			$this->cache->save($this->core->getSessionID() .'vCodes', $vCodes, CACHE_TTL);
		}
				
		$vCodes = json_encode($vCodes);
		$data['vCodes'] = $vCodes;
		$data['date'] = date('m/d/Y');
		$this->load->view('monitoring/transactions', $data);
	}
	
	function getData()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coresys/atm_model');
		$this->load->library('session');
		$this->load->library('shortxml');
		
		$cache = $this->cache;
		$atm   = $this->atm_model;
		$xml   = $this->shortxml;
		$core  = $this->core;
		$input = $this->input;
		
		$cmd 	 = $input->post('cmd', true);
		$dtLog	 = $core->formatDate('Y-m-d', $input->post('dtlog', TRUE));
		$limit 	 = $input->post('limit', true);
		$details = array();
		$cnt	 = 0;
		
		$result = $atm->getTransactionLog($cmd, $dtLog, $limit);
		$cnt = intval($result['numrows']);
		$resultArr = $result['result'];
		
		if ($cnt > 0) {
			foreach ($resultArr as $row) {
				$time 		= $core->formatDate('H:i:s', $row['dtlog']);
				$logkey 	= $row['logseqno'];
				$transCode 	= $row['trxcode'];
				$msgType	= $row['msgtype'];
				
				// if ACQ is true
				if ($row['termtype'] === 'ATM' && $row['chname'] === BANK_NETWORK) {
					
					$traceNo = $row['chseqno'];
					$sequenceNo = $row['tpseqno'];
					
				} else {
					
					$traceNo = $row['tpseqno'];
					$sequenceNo = $row['chseqno'];
					
				}
				
				//get mnemonic
				if (!$trxList = $cache->get($this->core->getSessionID() . 'trxList')) {
					// Save into the cache for 5 minutes
					$result = $atm->getTransactionList();
					$trxList = $result->result_array();
					
					array_push($trxList, array(
						'trxcode' => NULL, 
						'description' => 'Unknown')
					); 
					
					$result->free_result();
					$result->next_result();
					
					$cache->save($this->core->getSessionID() . 'trxList', $trxList, CACHE_TTL);
				}
				
				$mnemonic = NULL;
				foreach ($trxList as $trxList)
				{
					if (intval($transCode) > 0) {
						if (in_array($transCode, $trxList)) {
							$mnemonic = $trxList['mnemonic'];
							break;
						}
					} else {
						$mnemonic = 'UNKNOWN';
					}
				}
				//end
				
				if (!$msgTypes = $cache->get($this->core->getSessionID() . 'msgTypes')) {
					// Save into the cache for 5 minutes
					$result = $atm->getMessageTypes();
					$msgTypes = $result->result_array();
					
					array_push($msgTypes, array(
						'codeseqno' => NULL, 
						'codevalue' => 'Unknown')
					);
					
					$result->free_result();
					$result->next_result();
					
					$cache->save($this->core->getSessionID() . 'msgTypes', $msgTypes, CACHE_TTL);
				}
				
				$msgDesc = NULL;
				foreach ($msgTypes as $msgTypes) {
					if (intval($msgType) > 0) {
						$msgDesc = 'Unknown';
						if (in_array($msgType, $msgTypes)) {
							$msgDesc = $msgTypes['codevalue'];
							break;
						}
					}
				}
				//end
				
				$msgType	= $row['msgtype'] .': '. $msgDesc;
				$terminal	= $row['termtype'];
				$auth		= $row['authname'];
				$vCode		= $row['sysvcode'] !== '0' ? $row['sysvcode'] : NULL;
				
				//get void desc
				if (!$vCodeList = $cache->get($this->core->getSessionID() . 'vCodeList')) {
					// Save into the cache for 5 minutes
					
					$result = $atm->getVoidCodeList();
					$vCodeList = $result->result_array();
					
					array_push($vCodeList, array(
						'sysvcode' => NULL, 
						'shortdescription' => 'Unknown')
					);
					
					$result->free_result();
					$result->next_result();
					
					$cache->save($this->core->getSessionID() . 'vCodeList', $vCodeList, CACHE_TTL);
				}
				
				$vDesc = NULL;
				foreach ($vCodeList as $vCodeListx)
				{
					if (intval($vCode) > 0) {
						$vDesc = 'Unknown';
						if (in_array($vCode, $vCodeListx)) {
							$vDesc = $vCodeListx['shortdescription'];
							break;
						}
					}
				}
				//end
				
				$prodkey1	= $row['prkey1'];
				$amtreq		= $core->currency($row['amtreq']);
				$amtauth	= $core->currency($row['amtath']);
				$termid		= $row['termcode'];

				$details[] = array(
					$time,
					$logkey,
					$traceNo,
					$sequenceNo,
					$transCode,
					$mnemonic,
					$msgType,
					$terminal,
					$auth,
					$vCode,
					$vDesc,
					$prodkey1,
					$amtreq,
					$amtauth,
					$termid
				);
			}
				
			$success = TRUE;
		} else {
			$success = FALSE;
		}
		
		
		
		echo json_encode(array(
			'success' => $success,
			'details' => $details,
			'count'   => $cnt
		));
	}
}