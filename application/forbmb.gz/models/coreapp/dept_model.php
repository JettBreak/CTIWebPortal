<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dept_model extends CI_Model {
	
	function Dept_model()
	{
		$this->db = $this->load->database(DB1, TRUE);
		$this->security = $this->coresecurity;
		//sets the current database
		$this->security->_initDb($this->db);
	}
	
	function getDepartments()
	{
		$query = "CALL sp_getcodelist('DEPARTMENT')";	
		return $this->db->query($query);
	}
	
	//deptCode, deptName, branchID, IPAddress, workstation, userAudit, sessionID
	function insertDepartment()
	{
		$query = "CALL sp_insertdepartment(?,?,?,?,?,?,". APPSEQNO .",?)";
		return $this->security->validateQuery($query, func_get_args());
	}
	
	//deptCode, newDeptCode, deptName, branchID, IPAddress, workstation, userAudit, sessionID, isEdited
	function updateDepartment()
	{
		$query = "CALL sp_updatedepartment(?,?,?,?,?,?,?,". APPSEQNO .",?,?)";
		return $this->security->validateQuery($query, func_get_args());
	}
	
	//deptCode, branchID, IPAddress, workstation, userAudit, sessionID
	function deleteDepartment()
	{
		$query = "CALL sp_deletedepartment(?,?,?,?,?,". APPSEQNO .",?)";
		return $this->security->validateQuery($query, func_get_args());
	}
}