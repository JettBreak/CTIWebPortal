<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AllIBFTTrx extends CI_Controller {	

	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		//$this->core->checkUserAllows(OTHERCARDHOLDERATOURTERM_NO);
	}
	
	function preview()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coresys/reports_model');
		$this->load->library('pdf');
		$this->load->library('shortxml');
		
		$reports = $this->reports_model;
		$core 	 = $this->core;
		$pdf 	 = $this->pdf;		
		$xml	 = $this->shortxml;
	
		$userName = $core->getUserName();
		$instName = $core->getInstName();
		
		if ($core->canRep()) {
			$branchCode = $this->input->post('branch', TRUE);
			$branchName = $this->input->post('branchName', TRUE);
		} else {
			$branchCode = $core->getBranchCode();
			$branchName = $core->getBranchName();
		}
		
		$userAudit  = $core->getUserID();
		$sessionID  = $core->getSessionID();
		
		$termType = $this->input->post('termType', TRUE);
		$dtFrom = $core->formatDate('Y-m-d', $this->input->post('dtFrom', TRUE));
		$dtTo = $core->formatDate('Y-m-d', $this->input->post('dtTo', TRUE));
		$reportLog = $this->input->post('reports', TRUE);
		
		if ($dtFrom !== $dtTo) {
			//if same month, outputs: January 1 - 10, 2011
			if ($core->formatDate('Y-m', $dtFrom) === $core->formatDate('Y-m', $dtTo)) {
				$reportDate = $core->formatDate('F j', $dtFrom) .' - '. $core->formatDate('j, Y', $dtTo);
			} else {
				$reportDate = 'From '. $core->formatDate('F j, Y', $dtFrom) .' to '. $core->formatDate('F j, Y', $dtTo);
			}
		} else {
			$reportDate = $core->formatDate('F j, Y', $dtFrom);
		}
		
		$result = $reports->getIBFTTransactions($reportLog, $branchCode, $termType, $dtFrom, $dtTo); //$termType
		$tpt = $result->result_array();
		
		
		//echo '<pre>'.print_r($tpt).'</pre>';
		
		$data = array();
		if ($result->num_rows() === 0) {
			$data[' '] = array(
				'content' => '<tr><td></td></tr><tr><td colspan="17" align="center"><h3><font color="red">"No activity for the day"</font></h3></td></tr>',
				'load' => 0,
				'ibftwdlApprv' => 0,
				'ibftwdlRvrsl' => 0,
				'ibftwdlRejct' => 0,
				'ibfttrnApprv' => 0,
				'ibfttrnRvrsl' => 0,
				'ibfttrnRejct' => 0
			);
		}
		
		
		if (!$acctTypes = $this->cache->get($this->core->getSessionID() . 'acctTypes')) {
			$result->free_result();
			$result->next_result();
			
			$this->load->model('coreapp/card_model');	
			$result = $this->card_model->getAccountType();
			$acctTypes = $result->result_array();
			$this->cache->save($this->core->getSessionID() .'acctTypes', $acctTypes, CACHE_TTL);
		}

		$wdl = 0;
		$trn = 0;
		$pay = 0;
		$dep = 0;
		$adv = 0;
		$load= 0;
		$ibftreq = 0;
		$ibftwdl = 0;
		$ibfttrn = 0;
		
		//init array
		foreach ($tpt as $row) {
			//echo '<pre>'.print_r($row).'</pre>';
			$data[$row['termcode']] = array(
					'content' => '',
					'load' => 0,
					'ibftwdlApprv' => 0,
					'ibftwdlRvrsl' => 0,
					'ibftwdlRejct' => 0,
					'ibfttrnApprv' => 0,
					'ibfttrnRvrsl' => 0,
					'ibfttrnRejct' => 0
			);
		}
		
		$totalIBFT = array (
			'ibftwdlApprvSubTotal' => 0,
			'ibftwdlRvrslSubTotal' => 0,
			'ibftwdlRejctSubTotal' => 0,
			'ibfttrnApprvSubTotal' => 0,
			'ibfttrnRvrslSubTotal' => 0,
			'ibfttrnRejctSubTotal' => 0
			);
			
		$contentall = '';
		
		foreach ($tpt as $row) {
			$xml->setXML($row['xml1'] . $row['xml2'] . $row['xml3'] . $row['xml4'] . $row['xml5'] . $row['xml6']);
			
			//disregard all prepaid reload trx
			if (intval($xml->getValue('IBFTPTR')) === IBFTPTR) {
				continue;
			}
			
			$logkey = str_pad($row['logseqno'], 8, '0', STR_PAD_LEFT);
			$traceNo = $row['chseqno'];
			
			//acct1
			$acct1 = $row['acct1'];
			$a1Align = NULL;
			if (!$acct1) {
				$acct1 = '-';
				$a1Align = ' align="center"';
			}
			//end
			
			//acct2
			$acct2 = $row['acct2'];
			$a2Align = NULL;
			if (!$acct2) {
				$acct2 = '-';
				$a2Align = ' align="center"';
			}
			//end
			
			//get account code (TY)
			$acctType = $row['accttype1'];
			$acctDesc = NULL;
			foreach ($acctTypes as $r) {
				if ($r['accttype'] === $acctType) {
					$acctDesc = $r['acctcode'];
				}
			}
			//end
			
			// sysvcode
			$sysVCode = $row['sysvcode'];
			//end
			
			$result->free_result();
			$result->next_result();
			
			$fitCode = intval($row['acqcode']);
			$result = $reports->getFitName($fitCode);
			$r = $result->row_array();
			$fitName = $r['isomnem'];

			$result->free_result();
			$result->next_result();
			
			//remarks
			$remarks = $xml->getVALUE('SYSVDESC');
			$rAlign = NULL;
			if (!$remarks) {
				$remarks = '-';
				$rAlign = ' align="center"';
			}
			//end
			
			$amtReq = $row['amtreq'];
			$amtAth = $core->currency($row['amtath']);
			
			if (!array_key_exists($row['termcode'], $data)) {
				$data[$row['termcode']] = NULL;
			}
			
			$addAmt = floatval($row['amtath']);
			//echo '<pre>'.print_r($row['msgtype']).'</pre>';
			
			$mnemonic = $row['mnemonic'];
			switch ($row['msgtype']) {
				case 51:
				case 52:
					switch ($mnemonic) {
						case 'IBFTSA':
						case 'IBFTCA':
						case 'IBFTWDSA':
						case 'IBFTWDCA':
							$data[$row['termcode']]['ibftwdlApprv'] += $amtReq;
							$totalIBFT['ibftwdlApprvSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTWDSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
						case 'IBFTTRSA':
						case 'IBFTTRCA':
							$data[$row['termcode']]['ibfttrnApprv'] += $amtReq;
							$totalIBFT['ibfttrnApprvSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTTRSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
					}
					break;
				case 171:
					$sysVCode = $xml->getVALUE('SYSVCODE');
				case 53:
					switch ($mnemonic) {
						case 'IBFTSA':
						case 'IBFTCA':
						case 'IBFTWDSA':
						case 'IBFTWDCA':
							$data[$row['termcode']]['ibftwdlRejct'] += $amtReq;
							$totalIBFT['ibftwdlRejctSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTWDSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
						case 'IBFTTRSA':
						case 'IBFTTRCA':
							$data[$row['termcode']]['ibfttrnRejct'] += $amtReq;
							$totalIBFT['ibfttrnRejctSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTTRSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
					}
					break;
				case 71:
					switch ($mnemonic) {
						case 'IBFTWDSA':
						case 'IBFTWDCA':
							$data[$row['termcode']]['ibftwdlRvrsl'] += $amtReq;
							$totalIBFT['ibftwdlRvrslSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTWDSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
						case 'IBFTSA':
						case 'IBFTCA':
						case 'IBFTTRSA':
						case 'IBFTTRCA':
							$data[$row['termcode']]['ibfttrnRvrsl'] += $amtReq;
							$totalIBFT['ibfttrnRvrslSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTTRSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
					}
					break;
				case 73:
					switch ($mnemonic) {
						case 'IBFTWDSA':
						case 'IBFTWDCA':
							$data[$row['termcode']]['ibftwdlRejct'] += $amtReq;
							$totalIBFT['ibftwdlRejctSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTWDSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
						case 'IBFTSA':
						case 'IBFTCA':
						case 'IBFTTRSA':
						case 'IBFTTRCA':
							$data[$row['termcode']]['ibfttrnRejct'] += $amtReq;
							$totalIBFT['ibfttrnRejctSubTotal'] += $amtReq;
							if ($mnemonic == 'IBFTTRSA') {
								$mnemonic = 'IBFTSA';	
							} else {
								$mnemonic = 'IBFTCA';
							}
							break;
					}
					break;
				}
				
			//rules for ELD 8882 issue
			switch ($mnemonic) {
				case 'IBFTSA':
				case 'IBFTBTSA':
					if (intval($xml->getValue('IBFTPTR')) === IBFTPTR) {
						$mnemonic = 'LOADSA';
					}
					break;
				case 'IBFTCA':			
				case 'IBFTBTCA':
					if (intval($xml->getValue('IBFTPTR')) === IBFTPTR) {
						$mnemonic = 'LOADCA';
					}
					break;
			}
			//end
			
			// if ACQ is true
				if ($row['termtype'] === 'ATM' && $row['chname'] === BANK_NETWORK) {
					
					$traceNo = str_pad($row['chseqno'], 6, '0', STR_PAD_LEFT);
					$sequenceNo = str_pad($row['tpseqno'], 6, '0', STR_PAD_LEFT);
					
				} else {
					
					$traceNo = str_pad($row['tpseqno'], 6, '0', STR_PAD_LEFT);
					$sequenceNo = str_pad($row['chseqno'], 6, '0', STR_PAD_LEFT);
					
				}
			
			$content = '<tr>
				<td>'. $logkey .'</td>
				<td>'. $traceNo .'</td>
				<td>'. $sequenceNo .'</td>
				<td>'. $core->formatDate('H:i:s', $row['dtlog']) .'</td>
				<td>'. $core->formatDate('m/d/y', $row['dtlog']) .'</td>
				<td>'. $row['tpluno'] .'</td>
				<td>'. substr($row['prkey1'], 0, 6).'- '.substr($row['prkey1'], 6).'</td>
				<td align="center">'. $row['issname'] .'</td>
				<td'. $a1Align .'>'. substr($acct1, -12) .'</td>
				<td>'. $acctDesc .'</td>
				<td>'. $row['msgtype'] .'</td>	
				<td>'. $mnemonic .'</td>	
				<td>'. $fitName .'</td>	
				<td'. $a2Align .'>'. substr($acct2, -12) .'</td>	
				<td>'. $sysVCode .'</td>	
				<td'. $rAlign .'>'. $remarks .'</td>		
				<td align="right">'. $core->currency($amtReq) .'</td>
				<td align="right">'. $amtAth .'</td>
			</tr>';
				
			$data[$row['termcode']]['content'] .= $content;
		}
		
		/*$totals = '<tr align="right">
			<td><b>TOTAL:</b></td>
			<td>'. $core->currency($wdl) .'</td>
			<td>'. $core->currency($trn) .'</td>
			<td>'. $core->currency($pay) .'</td>
			<td>'. $core->currency($dep) .'</td>
			<td>'. $core->currency($adv) .'</td>
			<td>'. $core->currency($load) .'</td>
			<td>'. $core->currency($ibftreq) .'</td>
			<td>'. $core->currency($ibftwdl) .'</td>
			<td>'. $core->currency($ibfttrn) .'</td>
		</tr>';*/
		
		$result->free_result();
		$result->next_result();
		
		
		// set document information
		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor($userName);
		$pdf->SetTitle('All IBFT Transaction');
		$pdf->SetSubject(NULL);
		$pdf->SetKeywords(NULL);
		
		// set default header data
		//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
		$pdf->SetHeaderData(NULL);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setUser($core->getUserName());
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		//set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		//set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		// ---------------------------------------------------------
		
		// Set font
		// dejavusans is a UTF-8 Unicode font, if you only need to
		// print standard ASCII chars, you can use core fonts like
		// helvetica or times to reduce file size.
		$pdf->SetFont('helvetica', '', 7, '', true);
		
		// Add a page
		// This method has several options, check the source code documentation for more information.
		
		foreach ($data as $key => $d) {
			$pdf->AddPage('L', 'Letter');
			
			// Set some content to print
			$html = '<style>
			
			th {
				text-transform: uppercase;
				font-weight: bold;
				text-align: left;
			}
			</style>
			<h2>'.$instName.'</h2>
			<h1>ALL IBFT TRANSACTION: '.$key.'</h1>
			<h3>'. $branchName .'</h3>
			<h4>Transaction Date(s): '. $reportDate .'</h4>
			<table cellspacing="10" width="100%">
				<tr>
					<th width="140">LOGKEY</th>
					<th width="120">TRACE NO.</th>
					<th width="170">SEQUENCE NO.</th>
					<th width="120">TIME</th>
					<th width="120">DATE</th>
					<th width="100">LUNO</th>
					<th width="280">BANK ID / CARD #</th>
					<th width="120" align="center">ISSUER</th>
					<th width="230">FROM <br>ACCOUNT</th>
					<th width="60">TY</th>
					<th width="60">TC</th>
					<th width="160">TRXCODE</th>
					<th width="100">BANK</th>
					<th width="240">TO <br>ACCOUNT</th>
					<th width="70">VCD</th>
					<th width="290" align="center">REMARKS</th>
					<th width="130">TRX AMT</th>
					<th width="150">AMT AUTH</th>
				</tr>
				'. $d['content'] .'
				<tr>
					<td colspan="14">&nbsp;</td>
				</tr>
			</table>';
			
			$html .= '<table cellspacing="18" width="100%">
				<tr>
					<th align="center">&nbsp;</th>
					<th align="center">Apprvd IBFTWDL</th>
					<th align="center">Apprvd IBFTTRN</th>
					<th align="center">IBFTWDL Revrsl</th>
					<th align="center">IBFTTRN Revrsl</th>
					<th align="center">Rejctd IBFTWDL</th>
					<th align="center">Rejctd IBFTTRN</th>
				</tr>
				<tr align="right">
					<td><b>TOTAL:</b></td>
					<td>'. $core->currency($d['ibftwdlApprv']) .'</td>
					<td>'. $core->currency($d['ibfttrnApprv']) .'</td>
					<td>'. $core->currency($d['ibftwdlRvrsl']) .'</td>
					<td>'. $core->currency($d['ibfttrnRvrsl']) .'</td>
					<td>'. $core->currency($d['ibftwdlRejct']) .'</td>
					<td>'. $core->currency($d['ibfttrnRejct']) .'</td>
				</tr>
			</table>';
			// Print text using writeHTMLCell()
			$pdf->writeHTML($html, true, false, true, false, '');
		}
		$pdf->Output('allibfttrx_' . date('mdY') . '.pdf', 'I');
	}
}
/* End of file allibfttrx.php */
/* Location: ./application/reports/allibfttrx.php */