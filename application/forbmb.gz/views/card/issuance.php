<form id="issuanceForm" method="post">
    <input type="hidden" name="cifseqno" value="<?php echo $cifseqno; ?>"/>
    <input type="hidden" name="prseqno" id="prseqno" value=""/>
    <input type="hidden" name="acctType" id="acctType" value=""/>
    <div id="cardIssuance">
        <h1>Customer Card Issuance</h1>
        <div id="content"><span class="hint"> Enter Card Number then press ENTER key </span><span class="hint floatRight"><span class="red">*</span> - Required Fields </span>
            <table width="100%">
                <tr>
                    <td width="30%"><label for="custName">Customer Name:</label></td>
                    <td><input type="text" name="custName" id="custName" style="width:200px" value="<?php echo $custName; ?>" readonly/></td>
                </tr>
                <tr>
                	<td width="120"><label for="brseqno">Branch:</label></td>
                    <td colspan="3">
                    	<select id="brseqno" style="width:212px">
                            <?php echo html_entity_decode($branches); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="cardNo">Card Number: <span class="red">*</span></label></td>
                    <td colspan="3"><select name="cardBIN" id="cardBIN" style="width:80px">
                            <?php echo html_entity_decode($cardBIN); ?>
                        </select
                        ><input type="text" name="cardNo" id="cardNo" style="width:120px" class="validate[required,custom[onlyNumberSp]]" placeholder="<?php echo $cardNoPlaceholder; ?>"/><button id="verfiftBtn" value="card/issuance/verify">Verify</button>
                        </td>
                </tr>
                <tr>
                    <td><label for="cardStatus">Card Status:</label></td>
                    <td><input type="text" name="cardStatus" id="cardStatus" style="width:200px" readonly/></td>
                </tr>
                <tr>
                    <td><label for="cardType">Card Type:</label></td>
                    <td><input type="text" name="cardType" id="cardType" style="width:200px" readonly/></td>
                </tr>
            </table>
        </div>
    </div>
    <div id="bottom">
    	<span class="buttons floatLeft">
        	<button id="issueBtn" value="card/issuance/submit" disabled>Issue</button>
        </span>
        <span class="buttons floatRight">
            <button id="searchBtn">Search Customer</button
            ><button type="reset">Reset</button
            ><button class="closebtn">Close</button>
        </span>
	</div>
</form>
<script>
$(function () {	
    var searchBtn = '#searchBtn',
        verifyBtn = '#verifyBtn',
        issueBtn = '#issueBtn',
        resetBtn = 'button:reset',
        form = $('form');
	var branch = '#brseqno';
	var cardBIN = '#cardBIN';
	var cardNo = '#cardNo';
		
    form.validationEngine({
        ajaxFormValidation: true,
        onBeforeAjaxFormValidation: function () {
            if ($('#prseqno').val() === '') {
                var msg = 'Verifying card number...'
            } else {
                var msg = 'Sending transaction...'
            }
            waitMessage(msg);
        },
        onAjaxFormComplete: function (a, b, data, d) {
            if (data.verified === true) {
                $(MSGBOX).dialog('close');
                $('#prseqno').val(data['prseqno']);
                $('#acctType').val(data['acctType']);
                $('#cardStatus').val(data['cardStat']);
                $('#cardType').val(data['cardType']);
                $(verifyBtn).attr('disabled', 'disabled');
                $(issueBtn).removeAttr('disabled');
				
				$('#newCardNo2').attr('readonly', 'readonly');
            } else if (data['verified'] === false) {
                messageBox(data.message);
				$(resetBtn).trigger('click')
            }
            if (data.success === true) {
                messageBox(data.message);
                $(resetBtn).trigger('click');
            } else if (data.success === false) {
                messageBox(data.message);
                $(resetBtn).trigger('click');
            }
        },
        scroll: false
    });
    form.validationEngine('attach');
	
    $(searchBtn).click(function () {
        window.location.hash = 'customer/search/issuance';
        return false
    });
	
    $(resetBtn).click(function () {
        $('#prseqno, #acctType').val('');
        $(verifyBtn).removeAttr('disabled');
        $('#issueBtn').attr('disabled', 'disabled');
		$(cardNo).removeAttr('readonly');
    });
	
    $(issueBtn).click(function (e) {
        var a = $('#cardBIN option:selected').text() + $(cardNo).val();
        messageBox('Activate Card No. <strong>[' + a + ']</strong> ?', 'Confirm', 'confirm', function () {
            //$(MSGBOX).dialog('close');
            form.submit()
        });
		e.preventDefault();
    });
	
	$(branch + ',' + cardBIN).change(function () {		
		var selected = $(cardBIN).find('option:selected');
		var format = selected.attr('format');
		
		var brChar = 'B';
		var cnt = (format.split(brChar).length - 1);
		var rep = brChar.repeat(cnt);
		
		var br = zeroPad(cnt, $(branch).val());
		
		var mask = format.replace(rep, br);
		var placeholder = mask.replace(/N/g, '_');
		
		$(cardNo)
			.val('')
			.mask(mask)
			.attr('placeholder', placeholder);
	});
	
	$.mask.definitions = {
		'N': '[0-9]'
	};
	
	$(cardNo).mask('<?php echo $cardNoMask; ?>');
});
</script>