<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class EditInfo extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(ACCNTEDIT_NO);
	}
	
	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		
		$info = $_SESSION['accountInfo'];
		if (!$info) {
			$this->load->helper('url');
			redirect('welcome');
			exit();
		}
		
		$this->load->model('coreapp/card_model');
		$this->load->library('coreconverters');
		
		$data['cifseqno'] = $info['cifseqno'];
		$data['branchName'] = $info['brname'];
		$data['accountNo'] = $info['prkey'];
		$data['accountDesc'] = strtoupper($info['acctdesc']);
		$data['owner'] = $info['cifseqno'] ? $info['lastname'] .', '. $info['firstname'] .' '. $info['middlename'] : 'NONE';
		$data['authMode'] = strtoupper($info['authmode']);
		$data['accountStat'] = strtoupper($info['statdesc']);
		
		//tran allows		
		$result = $this->card_model->getDefaultTranAllows('ACCT');
		
		$data['tranAllows'] = NULL;
		
		$allows = $this->coreconverters->asciiHexToBin($info['allows']);
		
		foreach ($result->result_array() as $row) {
			$checked = substr($allows, $row['bitno'] - 1, 1) === '1' ? ' checked' : NULL;
			$data['tranAllows'] .= '<input type="checkbox" id="bit'. $row['bitno'] .'" name="allows[]" value="'. $row['bitno'] .'"'. $checked .'/>'. $row['description'] .'<br />';
		}
		
		$result->free_result();
		$result->next_result();
		//end
		
		$result = $this->card_model->getAcctCardLink($info['prseqno']);
		
		$cardLink = array();
		$cardsLinked = NULL;
		
		foreach ($result->result_array() as $row) {
			//add zeros to cifseqno
			/*$len = 8 - strlen($row['cifseqno']);
			$cifseqno = NULL;
			for ($i = 1; $i <= $len; $i++) {
				$cifseqno .= '0'; 
			}
			$cifseqno .= $row['cifseqno'];*/
			//end
			
			/*$cardLink[] = array(
				$row['prkey'],
				$cifseqno,
				$row['description']
			);*/
			$cardsLinked = '<tr>'.
				'<td>'. $row['prkey'] .'</td>'.
				'<td>'. $row['cifseqno'] .'</td>'.
				'<td>'.$row['description'] .'</td>'.
			'</tr>';
		}
		
		$data['cardsLinked'] = $cardsLinked;
			
		//$this->output->cache(CACHE_TTL);
		$data['title'] = 'Edit Account Information';
		$data['formAction'] = 'accounts/editinfo/submit';
		
		$this->load->view('accounts/editinfo', $data);
	}
	
	function getFormat($formatValue, $brChar)
	{
		$branchCode = $this->core->getBranchCode();
		
		$padCnt = substr_count($formatValue, $brChar);
		$get = str_repeat($brChar, $padCnt); //BBBBBB
		$brVal = str_pad($branchCode, $padCnt, '0', STR_PAD_LEFT);
		$newFormat = str_replace($get, $brVal, $formatValue);
		
		return $newFormat;
	}
	
	function submit()
	{
		$this->load->model('coreapp/card_model');
		$this->load->library('coreconverters');
		
		$card  = $this->card_model;
		$core  = $this->core;
		$input = $this->input;
		
		$info = $_SESSION['accountInfo'];
		if (!$info) {
			echo json_encode(array(
				'success' => FALSE,
				'message' => 'An error has occured'
			));
			exit;
		}
		
		$prseqno	 = $info['prseqno'];
		$cifseqno	 = $input->post('cifseqno', TRUE);
		$brseqno     = $info['brseqno'];
		$prKey       = $info['prkey'];
		$acctType    = $info['accttype'];
		$status      = $info['status'];
		
		$allows = $this->input->post('allows');
		
		if ($allows) {
			$max = max($allows);
			$bin = '';
			for ($i = 1; $i <= $max; $i++) {	
				if (in_array($i, $allows)) {
					$bin .= '1';
				} else {
					$bin .= '0';
				}
			}
		} else {
			$bin = '0';
		}
		
		$hex = $this->coreconverters->asciiBinToHex($bin);
		
		$ipAddress   = $core->getIPAddress();
		$workstation = $core->getWorkstation();
		$userAudit	 = $core->getUserID();
		$override	 = $this->session->userdata('userOverride');
		$sessionID	 = $core->getSessionID();
		
		$result = $card->updateAccount(
			$prseqno,
			$cifseqno,
			$brseqno,
			$prKey,
			$acctType,
			$status,
			$hex,
			$ipAddress,
			$workstation,
			$userAudit,
			$override,
			$sessionID
		);
		
		$this->session->unset_userdata('userOverride');
		$row = $result->row_array();
		
		if ($row['errno'] === '0') {
			$success = TRUE;
			$message = 'Account successfully updated';
		} else {
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
}
/* End of file newentry.php */
/* Location: ./application/contollers/accounts/newentry.php */