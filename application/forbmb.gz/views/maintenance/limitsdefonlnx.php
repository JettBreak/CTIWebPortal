<form id="onlineLimitsDefForm" method="post" action="<?php echo $formAction; ?>">
<input type="hidden" name="trandesc" id="trandesc" value="<?php echo $trandesc; ?>"/>
<input type="hidden" name="limitseqno" value="<?php echo $limitseqno; ?>"/>
<input type="hidden" name="method" value="<?php echo $method; ?>"/>
    <table>
    	<tr>
        	<td width="250"><label for="trxcode">Transaction:</label></td>
            <td>
            	<select name="trxcode" id="trxcode" style="width:182px;" class="validate[required]">
                	<?php echo html_entity_decode($trxList); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td><label for="cycledef"<?php echo $inputAttr; ?>>Default Cycle Amount:</label></td>
            <td><input type="text" name="cycledef" id="cycledef" maxlength="12" value="<?php echo $cycledef; ?>" class="currencyOnly"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="cyclemax"<?php echo $inputAttr; ?>>Maximum Cycle Amount:</label></td>
            <td><input type="text" name="cyclemax" id="cyclemax" maxlength="12" value="<?php echo $cyclemax; ?>" class="currencyOnly validate[required,funcCall[checkCyclemax]]"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="ctrdef">Default Counter:</label></td>
            <td><input type="number" name="ctrdef" id="ctrdef" maxlength="4" value="<?php echo $ctrdef; ?>" class="numbersOnly" step="1" min="0" max="9999"/></td>
        </tr>
        <tr>
            <td><label for="ctrmax">Maximum Counter:</label></td>
            <td><input type="number" name="ctrmax" id="ctrmax" maxlength="4" value="<?php echo $ctrmax; ?>" class="numbersOnly" step="1" min="0" max="9999"/></td>
        </tr>
        <tr>
            <td><label for="tranmindef"<?php echo $inputAttr; ?>>Default Min Transaction Amount:</label></td>
            <td><input type="text" name="tranmindef" id="tranmindef" maxlength="12" value="<?php echo $tranmindef; ?>" class="currencyOnly"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="tranmin"<?php echo $inputAttr; ?>>Minimum Transaction Amount:</label></td>
            <td><input type="text" name="tranmin" id="tranmin" maxlength="12" value="<?php echo $tranmin; ?>" class="currencyOnly validate[required,funcCall[checkInput]]"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="tranmaxdef"<?php echo $inputAttr; ?>>Default Max Transaction Amount:</label></td>
            <td><input type="text" name="tranmaxdef" id="tranmaxdef" maxlength="12" value="<?php echo $tranmaxdef; ?>" class="currencyOnly"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="tranmax"<?php echo $inputAttr; ?>>Maximum Transaction Amount:</label></td>
            <td><input type="text" name="tranmax" id="tranmax" maxlength="12" value="<?php echo $tranmax; ?>" class="currencyOnly validate[required,funcCall[checkInput]]"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="cycle">Cycle Period:</label></td>
            <td><input type="number" name="cycle" id="cycle" maxlength="2" value="<?php echo $cycle; ?>" class="numbersOnly" step="1" min="1" max="99"/></td>
        </tr>
        <tr>
            <td><label for="duralimit">Time Limit: (seconds)</label></td>
            <td><input type="number" name="duralimit" id="duralimit" maxlength="2" value="<?php echo $duralimit; ?>" class="numbersOnly" step="1" min="0" max="99"/></td>
        </tr>
        <tr>
            <td><label for="nonfeectr">No Fee Counter:</label></td>
            <td><input type="number" name="nonfeectr" id="nonfeectr" maxlength="4" value="<?php echo $nonfeectr; ?>" class="numbersOnly" step="1" min="0" max="9999"/></td>
        </tr>
        <tr>
            <td><label for="nonfeectrdef">Maximum No Fee Counter:</label></td>
            <td><input type="number" name="nonfeectrdef" id="nonfeectrdef" maxlength="4" value="<?php echo $nonfeectrdef; ?>" class="numbersOnly" step="1" min="0" max="9999"/></td>
        </tr>
        <tr>
            <td><label for="nonfeetran"<?php echo $inputAttr; ?>>No Fee Amount:</label></td>
            <td><input type="text" name="nonfeetran" id="nonfeetran" maxlength="12" value="<?php echo $nonfeetran; ?>" class="currencyOnly"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="nonfeetrandef"<?php echo $inputAttr; ?>>Maximum No Fee Amount:</label></td>
            <td><input type="text" name="nonfeetrandef" id="nonfeetrandef" maxlength="12" value="<?php echo $nonfeetrandef; ?>" class="currencyOnly"<?php echo $inputAttr; ?>/></td>
        </tr>
        <tr>
            <td><label for="nonfeecycle">No Fee Cycle Period:</label></td>
            <td><input type="number" name="nonfeecycle" id="nonfeecycle" maxlength="2" value="<?php echo $nonfeecycle; ?>" class="numbersOnly" step="1" min="1" max="99"/></td>
        </tr>
    </table>
</form>
<style>
#modalDialog td {
	padding:2px 0 !important;
}
#onlineLimitsDefForm input {
	width: 170px;
	text-align: right;
}
td {
	vertical-align: middle;
}
label[readonly] {
	color: #aaa;
}
input[readonly] {
	border: 1px solid #000;
}
.formError, .formErrorArrow {
	z-index: 9999;
}
</style>
<script>
$(function () {
	var form = $('#onlineLimitsDefForm');
	
	form.validationEngine({
        ajaxFormValidation: true,
        onBeforeAjaxFormValidation: function () {
            waitMessage('Saving...');
        },
        onAjaxFormComplete: function (a, b, data, d) {
            /*if (data.success === true) {
				//update datatable
				var columns = {
					4: '#cyclemax',
					6: '#ctrmax',
					7: '#tranmin',
					8: '#tranmax',
					12: '#nonfeectrmax',
					14: '#nonfeetranmax'
				};		
				$.each(columns, function(index, value) { 
					oTable.fnUpdate($(value).val(), oTable[2].fnGetPosition($('#<?php //echo $trxcode; ?>')[0]), index, false); //max counter
				});
				
				oTable.fnAdjustColumnSizing();
				
				messageBoxV2(data.message, 'Information', {
					'OK': function() {
						$(DIALOG).dialog('close');
					}
				});
            } else {
				messageBox(data.message);
			}*/
			
			if (data.success === true) {
				
				messageBoxV2(data.message, 'Information', {
					OK: function() {
						$(MSGBOX + ',' + DIALOG).dialog('close');
					}
				});
				
				if (parseInt(data.method) === 0) {
					oTable.fnAddData(data.row);
				} else {
					$.each(data.row, function(index, value) { 
						oTable.fnUpdate(value, oTable.fnGetPosition($('#' + data.trxcode)[0]), index, false);
					});
				}
				
				oTable.fnAdjustColumnSizing();
				
			} else {
				messageBox(data.message);
			}
        },
        scroll: false
    });
    form.validationEngine('attach');
	
	
	$('#trxcode').change(function () {
		var selected = $(this).find('option:selected');
		var isamtlimit = selected.attr('isamtlimit');
		
		if (isamtlimit === 'Y') {
			val = '0.00';
			isReadonly = false;
		} else {
			val = 'N/A';
			isReadonly = true;
		}
		
		$('#trandesc').val(selected.text());
		
		var selector = '#cycledef, label[for=cycledef]' +	//Default Cycle Amount
			',#cyclemax, label[for=cyclemax]' +				//Maximum Cycle Amount
			',#tranmindef, label[for=tranmindef]' +			//Default Min Transaction Amount
			',#tranmin, label[for=tranmin]' +				//Minimum Transaction Amount
			',#tranmaxdef, label[for=tranmaxdef]' +			//Default Max Transaction Amount
			',#tranmax, label[for=tranmax]' +				//Maximum Transaction Amount
			',#nonfeetran, label[for=nonfeetran]' +			//No Fee Amount
			',#nonfeetrandef, label[for=nonfeetrandef]';	//Maximum No Fee Amount
		
		$(selector)
			.val(val)
			.attr('readonly', isReadonly);
	});
});

function checkInput() {
	var tranmin = $('#tranmin').val();
	var tranmax = $('#tranmax').val();
	var cyclemax = $('#cyclemax').val();
		
	if ( tranmax !== 'N/A' ) {
		
		tranmin = parseFloat(tranmin.replace(/,/gi, ''));
		tranmax = parseFloat(tranmax.replace(/,/gi, ''));
		cyclemax = parseFloat(cyclemax.replace(/,/gi, ''));
		
		if ( !(tranmax >= tranmin) ) {
			return 'Maximum Transaction Amount must be greather than <br />or equal to Minimum Transaction Amount';
		} else {
			$('#tranmin').validationEngine('hidePrompt');
			$('#tranmax').validationEngine('hidePrompt');
		}
	
	}
}

function checkCyclemax() {
	var cyclemax = $('#cyclemax').val();
	var tranmax = $('#tranmax').val();
	
	if ( tranmax !== 'N/A' ) {
		
		cyclemax = parseFloat(cyclemax.replace(/,/gi, ''));
		tranmax = parseFloat(tranmax.replace(/,/gi, ''));
	
		if ( !(tranmax <= cyclemax) ) {
			return 'Maximum Transaction Amount must be less than <br />or equal to Maximum Cycle Amount';
		} else {
			$('#cyclemax').validationEngine('hidePrompt');
		}
		
	}
}
</script>