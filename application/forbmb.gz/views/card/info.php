<style>
.box {
	overflow:auto;
	border:1px solid #333;
}
</style>
<form id="cardUpdateForm" method="post">
<input type="hidden" name="prseqno" value="<?php echo $prseqno; ?>"/>
<input type="hidden" name="cifseqno" id="cifseqno" value="<?php echo $cifseqno; ?>"/>
<div id="cardInfo">
    <h1>Card Information</h1>
    <ul class="tabs fullTabs">
        <li><a href="#info">Information</a></li>
        <li><a href="#accounts" tableIndex="0">Accounts</a></li>
        <li><a href="#bills" tableIndex="1">Bills Payment</a></li>
        <li><a href="#limits" tableIndex="2"><?php echo $limitDesc; ?></a></li>
    </ul>
    <div class="tab_container">
        <div id="info" class="tab_content">
            <table width="100%" style="margin-top:0px">
                <tr>
                    <td width="120"><label for="branch">Branch:</label></td>
                    <td colspan="3"><input type="text" id="branch" style="width:200px" value="<?php echo $branch; ?>" readonly/></td>
                    <td rowspan="10" width="280">
                        Allowed Transactions:
                        <div style="height:126px;" class="box" id="allowedTrx">
                            <?php echo html_entity_decode($tranAllows); ?>
                        </div>
                        <br />Channel Locking:
                        <div style="height:84px;" class="box">
                            <?php echo html_entity_decode($allows); ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Card No.:</td>
                    <td colspan="3">
                    	<input type="text" style="width:200px" value="<?php echo $cardNo; ?>" readonly/>
                    </td>
                </tr>
                <tr>
                    <td><label for="acctType">Card Type:</label></td>
                    <td colspan="3">
                        <select name="acctType" id="acctType" style="width:212px">
                            <?php echo html_entity_decode($cardType); ?>
                        </select>
                    </td>
                </tr>
                <?php echo html_entity_decode($p1); ?>
                <tr>
                    <td><label for="custName">Customer Name:</label></td>
                    <td colspan="3">
                    	<input type="text" id="custName" style="width:277px;cursor:pointer" value="<?php echo $custName; ?>" readonly/><!--<button id="searchBtn">Search</button>-->
                    </td>
                </tr>
                <tr>
                    <td>Emboss Name:</td>
                    <td colspan="3"><input type="text" style="width:277px" maxlength="20" value="<?php echo $embossName; ?>" readonly/></td>
                </tr>
                <tr>
                    <td>Date Initial Issue:</td>
                    <td><input type="text" style="width:140px" value="<?php echo $dtInitIssue; ?>" readonly/></td>
                    <td>Issue Count:</td>
                    <td><input type="text" style="width:30px" value="<?php echo $issueCount; ?>" readonly/></td>
                </tr>
                <tr>
                    <td>Date Activated:</td>
                    <td><input type="text" style="width:140px" value="<?php echo $dtActivated; ?>" readonly/></td>
                </tr>
                <tr>
                    <td>Date Expiry:</td>
                    <td colspan="3"><input type="text" style="width:140px" value="<?php echo $dtExpiry; ?>" readonly/></td>
                </tr>
                <tr>
                    <td><label for="defFastCash">Default Fast Cash:</label></td>
                    <td colspan="3">
                    	<input type="text" name="fCash" id="fCash" style="width:100px" class="validate[required] currencyOnly" maxlength="9" value="<?php echo $defFastCashVal; ?>" <?php echo $defFastCashAttr; ?>/>
                        <select name="fType" id="fType" style="width:120px" <?php echo $defFastCashAttr; ?>>
                        	<?php echo html_entity_decode($defFastCash); ?>
                        </select>
					</td>
                </tr>
                <tr>
                    <td><label for="cardStatus">Card Status:</label></td>
                    <td colspan="3">
                    	<?php echo html_entity_decode($cardStatus); ?>
                    </td>
                </tr>
            </table>
        </div>
        <div id="accounts" class="tab_content nopadding">
            <table class="dataTable">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Account Type</th>
                        <th>Account No.</th>
                        <th>Authorization Type</th>
                        <th align="center">Primary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo html_entity_decode($accountLink); ?>
                </tbody>
            </table>
        </div>
        <div id="bills" class="tab_content nopadding">
            <table class="dataTable">
                <thead>
                    <tr>
                        <th>Institution</th>
                        <th>Ptr</th>
                        <th>Subscriber Number</th>
                        <th>Subscriber Name</th>
                        <th>Parent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo html_entity_decode($billsLink); ?>
                </tbody>
            </table>
        </div>
        <div id="limits" class="tab_content nopadding">
            <table class="dataTable">
                <thead>
                	<tr>
                    	<th>Transaction</th>
                        <th>limitseqno</th>
                        <th>trxcode</th>
                        <th>Available Cycle Amt.</th>
                        <th>Maximum Cycle Amt.</th>
                        <th>Available Counter</th>
                        <th>Max Counter</th>
                        <th>Min. Transaction Amt.</th>
                        <th>Max. Transaction Amt.</th>
                        <th>Cycle Period</th>
                        <th>Time Limit</th>
                        <th>Available No Fee Ctr.</th>
                        <th>Max. No Fee Ctr.</th>
                        <th>Available No Fee Amt.</th>
                        <th>Max. No Fee Amt.</th>
                        <th>No Fee Cycle Period</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo html_entity_decode($onlineLimits); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div id="bottom">
	<span class="buttons floatLeft">
    	<button id="updateBtn" value="card/info/submit">Update</button
        ><button id="searchBtn">Search</button
        ><button id="browseBtn">Browse</button
        ><button id="modifyBtn" class="hidden" disabled>Modify</button
        ><!--<button id="closeCardBtn">Close Card</button>--><?php echo html_entity_decode($resetLimitsBtn); ?>
    </span>
    <span class="buttons floatRight">
    	<button id="resetBtn" type="reset">Reset</button
        ><!--<button id="refreshBtn" class="hidden">Refresh</button
        >--><button class="closebtn">Close</button>
    </span>
</div>
</form>
<div id="customToolbar" class="hidden">
    <div class="top">
        <!--<div class="dataTables_custom floatLeft"><span class="info"></span></div>-->
        <div class="dataTables_custom floatLeft">
        	<span class="info">
        		<span class="label">Limit ID:</span>
                <select id="limitID" style="width:150px">
                	<?php echo html_entity_decode($limitID); ?>
                </select>
			</span>
            <span class="info">
        		<span class="label">PIN Retry Count:</span>
                <span id="pinRetryCnt"><?php echo $pinRetryCnt; ?></span>
			</span>
            <span class="info">
        		<span class="label">PIN Max Retry Count:</span>
                <span id="pinMaxRetryCnt"><input type="number" id="pinctr" style="width:30px" class="numbersOnly" value="<?php echo $pinMaxRetryCnt; ?>" maxlength="2" min="0" max="99" step="1"/></span>
			</span>
		</div>
    </div>
</div>
<style>
.dataTables_scrollBody{height:168px !important;max-height:168px !important;}
</style>
<script>
/*jQuery.fn.dataTableExt.oSort['formatted-num-asc'] = function (x,y){
 x = x.replace(/[^\d\-\.\/]/g,'');
 y = y.replace(/[^\d\-\.\/]/g,'');
 if(x.indexOf('/')>=0)x = eval(x);
 if(y.indexOf('/')>=0)y = eval(y);
 return x/1 - y/1;
}
jQuery.fn.dataTableExt.oSort['formatted-num-desc'] = function (x,y){
 x = x.replace(/[^\d\-\.\/]/g,'');
 y = y.replace(/[^\d\-\.\/]/g,'');
 if(x.indexOf('/')>=0)x = eval(x);
 if(y.indexOf('/')>=0)y = eval(y);
 return y/1 - x/1;
}*/

//option select
(function($) {
    $.fn.selected = function(fn) {
        return this.each(function() {
            var clicknum = 0;
            $(this).click(function() {
                clicknum++;
                if (clicknum == 2) {
                    clicknum = 0;
                    fn();
                }
            });
        });
    }
})(jQuery);

$(function () {
	var updateBtn = '#updateBtn';
    var searchBtn = '#searchBtn';
	var browseBtn = '#browseBtn';
	var modifyBtn = '#modifyBtn';
	var resetLimitsBtn = '#resetLimitsBtn';
	var resetBtn = '#resetBtn';
	var refreshBtn = '#refreshBtn';
	var form = $('form');
	var limits = {};
	var cboLimit = '#limitID';
	var jqxhr = null;
	var tempData = null;
	
	//current data
	var isChanged = false;
	var limitID = $(cboLimit).val();
	var pinctr = <?php echo $pinMaxRetryCnt; ?>;
	var currentData = null;
	
    form.validationEngine({
        ajaxFormValidation: true,
        onBeforeAjaxFormValidation: function () {
            waitMessage('Updating Card...');
        },
        onAjaxFormComplete: function (a, b, data, d) {
            if (data.success === true) {
				messageBoxV2(data.message, 'Information', {
					OK: function () {
						window.location.hash = 'card/browse';
					}
				});
            } else {
				messageBox(data.message);
			}
        },
        scroll: false
    });
    form.validationEngine('attach');

	oTable = [];
	
	//accounts link table
    oTable[0] = $('#accounts table').dataTable({
        bRetrieve: true,
        bJQueryUI: true,
        iDisplayLength: 100,
        aaSorting: [],
		aoColumns: [
			{ sClass: 'centerAlign' },
			null,
			null,
			null,
			{ sClass: 'centerAlign' },
		],
        sScrollY: '100%',
        sScrollX: '100%',
        sPaginationType: 'full_numbers'
    });
	
	//bills payment table
	oTable[1] = $('#bills table').dataTable({
        bRetrieve: true,
        bJQueryUI: true,
        iDisplayLength: 100,
        aaSorting: [],
		aoColumns: [
			null,
			null,
			null,
			null,
			{ 'bVisible': false },
		],
        sScrollY: '100%',
        sScrollX: '100%',
        sPaginationType: 'full_numbers'
    });
	
	//online limits table
	oTable[2] = $('#limits table').dataTable({
        bRetrieve: true,
        bJQueryUI: true,
        iDisplayLength: 100,
        aaSorting: [],
		aoColumns: [
			null, //Transaction
			{ bVisible: false }, //limitseqno
			{ bVisible: false }, //trxcode
			{
				sClass: 'rightAlign'//, //Available Cycle Amt.
				//sType: 'formatted-num'
			}, 
			{ sClass: 'rightAlign' },	//Maximum Cycle Amt.
			{ sClass: 'centerAlign'},	//Available Counter
			{ sClass: 'centerAlign'},	//Max Counter
			{ sClass: 'rightAlign' },	//Min. Transaction Amt.
			{ sClass: 'rightAlign' },	//Max. Transaction Amt.
			{ sClass: 'centerAlign'},	//Cycle Period
			{ sClass: 'centerAlign'},	//Time Limit
			{ sClass: 'centerAlign'},	//Available No Fee Ctr.
			{ sClass: 'centerAlign'},	//Max. No Fee Ctr.
			{ sClass: 'rightAlign' },	//Available No Fee Amt.
			{ sClass: 'rightAlign' },	//Max. No Fee Amt.
			{ sClass: 'centerAlign'} 	//No Fee Cycle Period
		],
        sScrollY: '100%',
        sScrollX: '100%',
        sPaginationType: 'full_numbers',
		fnInitComplete: function (oSettings) {
			currentData = this.oApi._fnGetDataMaster(oSettings);
		},
		fnRowCallback: function (nRow, aData, iDisplayIndex) {
			var rowAttr = {
				id: aData[2],
				title: aData[0]
			}	
            $(nRow).attr(rowAttr).unbind('click dblclick').click(function () {
				//close dialog boxes
				if ($(MSGBOX).length > 0) {
					$(MSGBOX).dialog('close');
				}
				
				//highlight rows
				$('tbody tr').removeClass('rowSelected');
                $(this).addClass('rowSelected');
				
				//set temp var
				limits = {
					prseqno: <?php echo $prseqno; ?>,
					description: aData[0],
					limitseqno: aData[1],
					trxcode: aData[2],
					cycleavail: aData[3],
					cyclemax: aData[4],
					ctravail: aData[5],
					ctrmax: aData[6],
					tranmin: aData[7],
					tranmax: aData[8],
					cycle: aData[9],
					duralimit: aData[10],
					nonfeectravail: aData[11],
					nonfeectrmax: aData[12],
					nonfeetranavail: aData[13],
					nonfeetranmax: aData[14],
					nonfeecycle: aData[15]
				}
				
                $(modifyBtn).removeAttr('disabled')
            }).dblclick(function () {
                $(modifyBtn).trigger('click');
            });
			$('tbody tr').removeClass('rowSelected');
            $(modifyBtn).attr('disabled', 'disabled');
			
			//unset temp obj
			limits = {};
            return nRow
        }
    });
    $('.dataTables_length, .dataTables_paginate').remove();
	
	$('#limits .ui-toolbar:first').append($('#customToolbar .top').html());
	
    $(DATATABLE).columnTreeTable();
    $(TABCONTENT).hide();
    $(TABS).first().addClass('active').show();
    $(TABCONTENT).first().show();
	
    $(TABS).click(function () {
		
		$(MSGBOX).dialog('close');
		$(DIALOG).dialog('close');
		
        if (!$(this).hasClass('active')) {
			
            $(TABS).removeClass('active');
            $(this).addClass('active');
            $(TABCONTENT).hide();
			
            var tab = $(this).find('a').attr('href');
			var tableIndex = $(this).find('a').attr('tableIndex');
			
			switch (tab) {
				case '#info':	
					$(updateBtn + ',' + searchBtn + ',' + browseBtn + ',' + resetBtn).show();
					$(modifyBtn + ',' + resetLimitsBtn).hide();
					break;
				case '#accounts':
					$(updateBtn + ',' + searchBtn + ',' + browseBtn + ',' + resetBtn + ',' + modifyBtn + ',' + resetLimitsBtn).hide();
					break;
				case '#bills':
					$(updateBtn + ',' + searchBtn + ',' + browseBtn + ',' + resetBtn + ',' + modifyBtn + ',' + resetLimitsBtn).hide();
					break;
				case '#limits':
					$(searchBtn + ',' + browseBtn).hide();
					//$(updateBtn + ',' + modifyBtn + ',' + resetLimitsBtn + ',' + refreshBtn).show();
					$(updateBtn + ',' + modifyBtn + ',' + refreshBtn).show();
					break;
			}
			
            $(tab).show();
			
			if (tab !== '#info') {
				//$.fn.dataTableExt.iApiIndex = tableIndex;
            	oTable[tableIndex].fnAdjustColumnSizing();
			}
        }
        return false;
    });
	
	$(updateBtn).click(function (e) {
		var tab = $(TABS + '.active').find('a').attr('href');
		if (tab === '#limits') { //update limits
		
			var limitseqno = parseInt($(cboLimit).val());
			var data = {
				prseqno: '<?php echo $prseqno; ?>',
				limitseqno: limitseqno
			}
			
			//if PIN max retry count changed
			var newPINctr = parseInt($('#pinctr').val());
			if (pinctr !== newPINctr) {
				data.pinctr = newPINctr;
				isChanged = true;
			}
			
			//if default card limit changed
			var newLimitID = $(cboLimit).val();
			/*if (limitID !== newLimitID) {
				data.limitseqno = limitseqno;
				isChanged = true;
			}*/
			
			if (isChanged === true) {
				messageBox('Save changes?', 'Confirm', 'confirm', function () {
					saveChanges(data);
					jqxhr.success(function (data) {
						messageBox(data.message);
						limitID = newLimitID;
						pinctr = newPINctr;
						
						$('a[href="#limits"]').text('Online Limits');
					});
				});
			} else {
				messageBox('No changes made');
			}
			
		} else { //update info
			if (form.validationEngine('validate') === true) {
				messageBox('Are all entries correct?', 'Confirm', 'confirm', function () {
					form.submit();
				});
			}
		}
		e.preventDefault();
	});
	
    $(searchBtn).click(function () {
        window.location.hash = 'card/verify/info';
        return false;
    });
	
	$(browseBtn).click(function () {
        window.location.hash = 'card/browse';
        return false;
    });
	
	$(modifyBtn).click(function (e) {
		
		if (isChanged) {
			messageBoxV2('You must save default card limit first.<br />Do you want to save?', 'Confirm', {
				OK: function () {
					var newLimitID = parseInt($(cboLimit).val());
					
					var data = {
						prseqno: <?php echo $prseqno; ?>,
						limitseqno: newLimitID
					}
			
					saveChanges(data);
					jqxhr.success(function (data) {
						limitID = newLimitID;
						
						messageBoxV2(data.message, 'Information', {
							OK: function () {
								$(MSGBOX).dialog('close');
								modifyLimits();
							}
						});
						/*$(MSGBOX).dialog('option', {
							beforeClose: function (e, ui) {
								if ($(MSGBOX).length > 0) {
									$(MSGBOX).dialog('close');
								}
							}
						});*/
					});
					
				},
				Cancel: function () {
					$(this).dialog('close');
					//return false;
				}
			});
		} else {
			modifyLimits();
		}
		
		
		function modifyLimits()
		{
			if (limits) {
				//serialize AJAX request
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'card/onlinelimits/cache',
						data: limits,
						dataType: 'json',
						success: function (data) {
							if (data.success === true) {
								var buttons = {
									Save: function () {
										var form = $('#onlineLimitsForm');
										if (form.validationEngine('validate') === true) {
											messageBoxV2('Update online limits?', 'Confirm', {
												OK: function () {
													form.submit();
												},
												Cancel: function () {
													$(this).dialog('close');
													//return false;
												}
											});
										}
										//return false;
									},
									Cancel: function () {
										$(this).dialog('close');
										//return false;
									}
								}
								modalDialog('card/onlinelimits', limits.description +' LIMITS', buttons, 400);
								$(DIALOG).one('dialogbeforeclose', function () {
									if ($(MSGBOX).length > 0) {
										$(MSGBOX).dialog('close');
									}
								});
							} else {
								messageBox('An error has occured');
							}
						}
					})
				);
			} else {
				messageBox('Please select an item from the list')
			}
		}
        e.preventDefault();
    });
	
	$('#fCash').focusout(function (e) {
		this.value = formatCurrency(this.value);
	}).focusin(function (e) {
		if (this.value === '0.00') {
			this.value = '';
		}
    });
	
	//online limits
	$(resetLimitsBtn).click(function (e) {
		//messageBox('This button is under development.<br />Please contact software development team');
		messageBox('Reset PIN Retry Counter?', 'Confirm', 'confirm', function () {
			requests.push(
				$.ajax({
					type: 'POST',
					url: 'card/info/resetPIN',
					data: {
						prseqno: <?php echo $prseqno; ?>
					},
					dataType: 'json',
					beforeSend: function () {
						waitMessage('Resetting...');
					},
					success: function (data) {
						messageBox(data.message);
						if (data.success === true) {
							$(MSGBOX).one('dialogbeforeclose', function () {
								$('#pinRetryCnt').text('0');
							});
						}
					}
				})
			)
		});
		e.preventDefault();
	});
	
	$(cboLimit).selected(function () {
		var selected = $(cboLimit).find('option:selected')
		var limitseqno = selected.attr('value');
		var pinMaxRetry = selected.attr('pinmaxretry');
		var description = selected.html();

		if (description && selected.val() !== '') {
			messageBoxV2('Load default online limits for <strong>['+ description +']</strong>?', 'Confirm', {
				'OK': function () {
					isChanged = true;
					requests.push(
						$.ajax({
							type: 'GET',
							url: 'card/onlinelimits/loaddefaults',
							data: {
								limitseqno: limitseqno
							},
							dataType: 'json',
							beforeSend: function () {
								waitMessage('Retrieving default online limits...');
							},
							success: function (data) {
								if (data.success === true) {
									$(MSGBOX).dialog('close');
									
									$(cboLimit + ' option[value=""]').remove();
									
									//populate datatable and pinMaxRetry input
									oTable[2].fnClearTable(0);
									oTable[2].fnAddData(data.details);
									oTable[2].fnDraw();
									oTable[2].fnAdjustColumnSizing();
									
									$('#pinMaxRetryCnt input').val(pinMaxRetry);
									
									//save to temp
									tempData = data['details'];
									//end
								} else {
									messageBox(data['details']);
								}
							}
						})
					);
				},
				'Cancel': function () {
					$(cboLimit).val(limitID);
					$(this).dialog('close');
				}
			});
		}
		
		$(MSGBOX).dialog({
			closeOnEscape: false
		});
		
		$('.ui-dialog-titlebar-close span').click(function () {
			$(cboLimit).val(limitID);
		});
		
		//e.preventDefault();
	});
	
	$('#pinctr').focusout(function (e) {
		var maxInput = 99;
		var minInput = 0;
		var val = parseInt(this.value);
		
		if (val < minInput || this.value === '') {
			return this.value = minInput;
		}
		
		if (val > maxInput) {
			return this.value = maxInput;
		}
		return this.value = val;
	});
	
	$('#custName').bind('click', function () {
		$(this).attr('disabled');
		$(this).validationEngine('hidePrompt');
		searchCustomer();
		return false;
	});
	
	$(resetBtn).click(function (e) {
		var tab = $(TABS + '.active').find('a').attr('href');
		if (tab === '#limits') { //update limits
		
			//if PIN max retry count changed
			var newPINctr = parseInt($('#pinctr').val());
			if (pinctr !== newPINctr) {
				isChanged = true;
			}
			
			//if default card limit changed
			var newLimitID = $(cboLimit).val();
			if (limitID !== newLimitID) {
				isChanged = true;
			}
				
			if (isChanged === true) {
				messageBoxV2('Revert changes?', 'Confirm', {
					'OK': function () {
						isChanged = false;
						var tab = $(TABS + '.active').find('a').attr('href');
						if (tab === '#limits') { //update limits
							oTable[2].fnClearTable(0);
							oTable[2].fnAddData(currentData);
							oTable[2].fnDraw();
							oTable[2].fnAdjustColumnSizing();
							
							$(cboLimit).val(limitID);
							$('#pinctr').val(pinctr);
							$(MSGBOX).dialog('close');
						}
					},
					'Cancel': function () {
						$(this).dialog('close');
					}
				});
			} else {
				messageBox('No changes made');
			}
			e.preventDefault();
		}
	});
	
	/*$(refreshBtn).click(function (e) {
		getData();
	});*/
	
	function getData()
	{
		//serialize request
		requests.push(
			jqxhr = $.ajax({
				type: 'POST',
				url: 'card/onlinelimits/get',
				data: {
					prseqno: <?php echo $prseqno; ?>
				},
				dataType: 'json',
				beforeSend: function () {
					abortAJAXRequests();
					waitMessage('Retrieving Data...');
				},
				success: function (data) {
					if (data.success === true) {
						oTable[2].fnClearTable(0);
						oTable[2].fnAddData(data.details);
						oTable[2].fnDraw();
						oTable[2].fnAdjustColumnSizing();
					}
				},
				complete: function () {
					$(MSGBOX).dialog('close');
				}
			})
		);
		e.preventDefault();
	}
	
	function saveChanges(data)
	{
		//serialize request
		requests.push(
			jqxhr = $.ajax({
				type: 'POST',
				url: 'card/onlinelimits/setlimits',
				data: data,
				dataType: 'json',
				beforeSend: function () {
					waitMessage('Saving...');
				},
				complete: function () {
					isChanged = false;
					currentData = tempData;
				}
			})
		);
	}
	//end
});
</script>