<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class POSEdit extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(MAINTENANCEPOS_NO);
	}

	function index($termCode)
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coresys/pos_model');
		$this->load->model('coreapp/area_model');
		
		$cache = $this->cache;
		$pos = $this->pos_model;
		$core = $this->core;
		
		$result = $pos->getPOSInfo($termCode);
		
		if (!$termCode || ($result->num_rows() === 0)) {
			$this->load->helper('url');
			redirect('maintenance/pos');
			exit();
		}
		
		$row = $result->row_array();
		
		$result->free_result();
		$result->next_result();
		
		$data['termID'] = $row['termid'];
		$data['luno'] = $row['luno'];
		$data['desc'] = $row['description'];
		$data['status'] = $row['statdesc'] ? $row['statdesc'] : $row['status'] .'-Unknown';
		$progLang = $row['proglang'];
		$location = $row['loccode'];
		
		//get POS language from cache
		if (!$posLang = $cache->get($this->core->getSessionID() . 'posLang')) {			
			$result = $pos->getPOSLanguage();
			$posLang = $result->result_array();
			
			$result->free_result();
			$result->next_result();
		
			$cache->save($this->core->getSessionID() . 'posLang', $posLang, CACHE_TTL);
		}
		
		$data['posLang'] = NULL;
		foreach ($posLang as $row) {
			$selected = ($row['termlang'] === $progLang ? ' selected' : NULL);
			$data['posLang'] .= '<option value="'. $row['termlang'] .'"'. $selected .'>'. $row['description'] .'</option>';
		}
		//end
		
		//location
		if ($core->isHeadOffice()) {
			$result = $pos->getAllLocations();
		} else {
			$result = $pos->getLocations($core->getBranchCode());
		}
		$resultArr = $result->result_array();
		
		$result->free_result();
		$result->next_result();
		
		$data['location'] = NULL;
		
		$areaName = NULL;
		$brchName = NULL;

		foreach ($resultArr as $row) {
			$result = $this->area_model->getAreaByBranch($row['brcode']);
			$r = $result->row_array();
			
			if ($location === $row['loccode']) {
				$areaName = $r['areaname'];
				$brchName = $r['brname'];
				$selected = ' selected';
			} else {
				$selected = NULL;
			}
			
			$data['location'] .= '<option value="'. $row['loccode'] .'" areaname="'. $r['areaname'] .'" brname="'. $r['brname'] .'"'. $selected .'>'. $row['location'] .'</option>';
			
			$result->free_result();
			$result->next_result();
		}
		//end
		
		$data['areaName'] = $areaName;
		$data['branchName'] = $brchName;
	
		$data['header'] = 'Update POS Information';
		$data['termCodeParams'] = 'value="'. $termCode .'" class="validate[required] numbersOnly" maxlength="8" readonly';
		$data['termIDParams'] = 'readonly';
		$data['submitBtnVal'] = 'maintenance/posedit/submit';
		$data['waitMsg'] = 'Updating POS entry...';
		$data['submitBtnMsg'] = 'The modification will alter the terminal behavior. Do you want to continue?';
		
		$this->load->view('maintenance/posx', $data);
	}
	
	function submit()
	{
		$this->load->model('coreapp/user_model');
		
		$core  = $this->core;
		$input = $this->input;
		
		$userAudit = $core->getUserID();
		$sessionID = $core->getSessionID();
		
		$row = $this
			->user_model
			->checkLogin($userAudit, $sessionID)
			->row_array();
			
		if ($row['errno'] !== '8') { //if session valid
			$termCode = $input->post('posCode', TRUE);
			$termID   = $input->post('posID', TRUE);
			$luno	  = $input->post('luno', TRUE);
			$locCode  = $input->post('location', TRUE);
			$desc	  = $input->post('description', TRUE);
			$progLang = $input->post('progLang', TRUE);
			
			$this->load->model('coresys/pos_model');
			
			$result = $this->pos_model->updatePOSTerminal(
				$termCode, $termID, $luno, $locCode, $desc, $progLang
			);
			
			$row = $result->row_array();
			
			if ($row['errno'] === '0') {
				$success = TRUE;
				$message = 'POS entry updated successfully';
			} else {
				$success = FALSE;
				$message = $row['errmsg'];
			}
		} else { //if invalid userID / session then logout
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message,
			'errorno' => $row['errno']
		));
	}
}
/* End of file posedit.php */
/* Location: ./application/contollers/maintenance/posedit.php */