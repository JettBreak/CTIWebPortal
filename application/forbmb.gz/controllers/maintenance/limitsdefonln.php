<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class LimitsDefOnln extends CI_Controller {	

	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		//$this->core->checkUserAllows(MAINTENANCEPOS_NO);
	}
	
	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coreapp/card_model');
		
		//account types
		$result = $this->card_model->getAccountTypeLimit();
		
		$accountTypes = NULL;
		if ($result->num_rows() > 0) {
			foreach ($result->result_array() as $row) {
				$accountTypes .= '<option value="'. $row['accttype'] .'">'. $row['description'] .'</option>';
			}
		} else {
			$accountTypes = '<option value="">No Data Defined</option>';
		}
		$data['accountTypes'] = $accountTypes;
		
		$row = $result->row_array();
		$firstAcctType = $row['accttype'];
		
		$result->free_result();
		$result->next_result();
		//end
		
		//limit names
		
		$result = $this->card_model->getDefaultOnlineLimitList($firstAcctType);
		
		$limitNames = NULL;
		if ($result->num_rows() > 0) {
			foreach ($result->result_array() as $row) {
				$pinctrdef = $row['pinctrdef'];
				$pinctrmax = $row['pinctrmax'];
				
				if ($limitNames === NULL) {
					$data['pinctrdef'] = $pinctrdef;
					$data['pinctrmax'] = $pinctrmax;
				}
				
				$limitNames .= '<option value="'. $row['limitseqno'] .'" pinctrdef="'. $pinctrdef .'" pinctrmax="'. $pinctrmax .'">'. $row['description'] .'</option>';
			}
		} else {
			$limitNames = '<option value="">No Data Defined</option>';
			
			$data['pinctrdef'] = 0;
			$data['pinctrmax'] = 0;
		}
		$data['limitNames'] = $limitNames;
		
		
		$result->free_result();
		$result->next_result();
		//end
		
		//get branches
		if (!$branches = $this->cache->get($this->core->getSessionID() . 'branches')) {
			$this->load->model('coreapp/branch_model');
			$result = $this->branch_model->getBranchList();
		
			$branches = $result->result_array();
			
			$result->free_result();
			$result->next_result();
			$this->cache->save($this->core->getSessionID() .'branches', $branches, CACHE_TTL);
		}
		
		$data['branches'] = '<option value="9999">(Global)</option>';
		$currentBrCode = NULL;
		
		if (count($branches) > 0) {
			foreach ($branches as $row) {
				//if user branch is not allowed to monitor users from other branches
				$matched = $row['brseqno'] === $this->core->getBranchID() ? TRUE : FALSE;
				
				if (!$this->core->canUser() && $matched) {
					$data['branches'] = '<option value="'. $row['brcode'] .'">'. $row['brname'] .'</option>';
					break;
				}
				
				if ($matched) {
					$selected = ' selected';
					$currentBrCode = $row['brcode'];
				} else {
					$selected = NULL;
				}
				
				$data['branches'] .= '<option value="'. $row['brcode'] .'"'. $selected .'>'. $row['brname'] .'</option>';
			}
		} else {
			$data['branches'] = '<option value="">No Branches Defined</option>';
		}
		//end
		
		$this->load->view('maintenance/limitsdefonln', $data);
	}
	
	function getData()
	{
		$this->load->model('coreapp/card_model');
		
		$core = $this->core;
		
		$limitseqno = $this->input->get('limitseqno', TRUE);
		$result = $this->card_model->getCardDefaultOnlineLimits($limitseqno);
		
		$details = array();
		
		if ($result->num_rows() > 0) {
		
			foreach ($result->result_array() as $row) {
				if ($row['isamtlimit'] === 'N') {
					$cycledef = 'N/A';
					$cyclemax = 'N/A';
					$tranmindef = 'N/A';
					$tranmin = 'N/A';
					$tranmaxdef = 'N/A';
					$tranmax = 'N/A';
					$nonfeetran = 'N/A';
					$nonfeetrandef = 'N/A';
				} else {
					$cycledef = $core->currency($row['cycledef']);
					$cyclemax = $core->currency($row['cyclemax']);
					$tranmindef = $core->currency($row['tranmindef']);
					$tranmin = $core->currency($row['tranmin']);
					$tranmaxdef = $core->currency($row['tranmaxdef']);
					$tranmax = $core->currency($row['tranmax']);
					$nonfeetran = $core->currency($row['nonfeetran']);
					$nonfeetrandef = $core->currency($row['nonfeetrandef']);
				}
				
				$details[] = array(
					$row['description'],	//0
					$row['limitseqno'],		//1
					$row['trxcode'],		//2
					$cycledef,				//3
					$cyclemax,				//4
					$row['ctrdef'] ? $row['ctrdef'] : 0,	//5
					$row['ctrmax'] ? $row['ctrmax'] : 0,	//6
					$tranmindef,			//7
					$tranmin,				//8
					$tranmaxdef,			//9
					$tranmax,				//10
					$row['cycle'] ? $row['cycle'] : 0,		//11
					$row['duralimit'] ? $row['duralimit'] : 0,	//12
					$row['nonfeectr'] ? $row['nonfeectr'] : 0,	//13
					$row['nonfeectrdef'] ? $row['nonfeectrdef'] : 0,	//14
					$nonfeetran,			//15
					$nonfeetrandef,			//16
					$row['nonfeecycle'] ? $row['nonfeecycle'] : 0		//17
				);
			}
			
			$success = TRUE;
		} else {
			$success = FALSE;
		}
		
		//$_SESSION['limitxx'] = $details;
		
		echo json_encode(array(
			'success' => $success,
			'details' => $details
		));
	}
	
	function getLimitNames()
	{
		$this->load->model('coreapp/card_model');
		//limit names
		$acctType = $this->input->get('acctType', TRUE);
		
		$result = $this->card_model->getDefaultOnlineLimitList($acctType);
		
		$limitNames = NULL;
		if ($result->num_rows() > 0) {
			foreach ($result->result_array() as $row) {
				$pinctrdef = $row['pinctrdef'];
				$pinctrmax = $row['pinctrmax'];
				
				$limitNames .= '<option value="'. $row['limitseqno'] .'" pinctrdef="'. $pinctrdef .'" pinctrmax="'. $pinctrmax .'">'. $row['description'] .'</option>';
			}
		} else {
			$limitNames = '<option value="">No Data Defined</option>';
			$pinctrdef = 0;
			$pinctrmax = 0;
		}
		
		$result->free_result();
		$result->next_result();
		//end
		
		echo json_encode(array(
			'success' => TRUE,
			'options' => $limitNames
		));
	}
	
		
	function cache()
	{		
		$_SESSION['onlineLimitsDef'] = $_POST;

		echo json_encode(array(
			'success' => TRUE
		));
	}
	
	function remove()
	{
		$this->load->model('coreapp/card_model');
		
		$input = $this->input;
		$core = $this->core;
		
		$limitseqno = $input->post('limitseqno', TRUE);
		$trxcode = $input->post('trxcode', TRUE);
		$brseqno = $core->getBranchID();
		$ipAddress = $core->getIPAddress();
		$workstation = $core->getWorkstation();
		$userAudit = $core->getUserID();
		$override = '';
		$sessionID = $core->getSessionID();
		
		$result = $this->card_model->deleteTranOnlineLimit(
			$limitseqno,
			$trxcode,
			$brseqno,
			$ipAddress,
			$workstation,
			$userAudit,
			$override,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
		} else {
			$success = TRUE;
		}
		
		$message = $row['errmsg'];
		
		$result->free_result();
		$result->next_result();
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
	
	function submit()
	{
		$this->load->model('coreapp/card_model');
		
		$input = $this->input;
		$core = $this->core;
		
		$trandesc = $input->post('trandesc', TRUE);
		$method = intval($input->post('method', TRUE));
		
		$limitseqno = $input->post('limitseqno', TRUE);
		$trxcode = $input->post('trxcode', TRUE);
		$cyclemax = str_replace(',', '', $input->post('cyclemax', TRUE));
		$cycledef = str_replace(',', '', $input->post('cycledef', TRUE));
		$ctrmax = $input->post('ctrmax', TRUE);
		$ctrdef = $input->post('ctrdef', TRUE);
		$tranmax = str_replace(',', '', $input->post('tranmax', TRUE));
		$tranmaxdef = str_replace(',', '', $input->post('tranmaxdef', TRUE));
		$tranmin = str_replace(',', '', $input->post('tranmin', TRUE));
		$tranmindef = str_replace(',', '', $input->post('tranmindef', TRUE));
		$cycle = $input->post('cycle', TRUE);
		$duralimit = $input->post('duralimit', TRUE);
		$nonfeectr = $input->post('nonfeectr', TRUE);
		$nonfeectrdef = $input->post('nonfeectrdef', TRUE);
		$nonfeetran  = str_replace(',', '', $input->post('nonfeetran', TRUE));
		$nonfeetrandef = str_replace(',', '', $input->post('nonfeetrandef', TRUE));
		$nonfeecycle = $input->post('nonfeecycle', TRUE);
		$brseqno = $core->getBranchID();
		$ipAddress = $core->getIPAddress();
		$workstation = $core->getWorkstation();
		$userAudit = $core->getUserID();
		$override = '';
		$sessionID = $core->getSessionID();
		
		$result = $this->card_model->setDefaultTranOnlineLimit(
			$limitseqno,
			$trxcode,
			$cyclemax,
			$cycledef,
			$ctrmax,
			$ctrdef,
			$tranmax,
			$tranmaxdef,
			$tranmin,
			$tranmindef,
			$cycle,
			$duralimit,
			$nonfeectr,
			$nonfeectrdef,
			$nonfeetran,
			$nonfeetrandef,
			$nonfeecycle,
			$brseqno,
			$ipAddress,
			$workstation,
			$userAudit,
			$override,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
			//$message = $row['errmsg'];
		} else {
			$success = TRUE;
			//$message = 'Created successfully';
		}
		$message = $row['errmsg'];
		
		$result->free_result();
		$result->next_result();
		
		$row = array(
			$trandesc,
			$limitseqno,
			$trxcode,
			$input->post('cycledef', TRUE),
			$input->post('cyclemax', TRUE),
			$ctrdef,
			$ctrmax,
			$input->post('tranmindef', TRUE),
			$input->post('tranmin', TRUE),
			$input->post('tranmaxdef', TRUE),
			$input->post('tranmax', TRUE),
			$cycle,
			$duralimit,
			$nonfeectr,
			$nonfeectrdef,
			$input->post('nonfeetran', TRUE),
			$input->post('nonfeetrandef', TRUE),
			$nonfeecycle
		);
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message,
			'row' => $row,
			'method' => $method,
			'trxcode' => $trxcode
		));
	}
	
	function delete()
	{
		$this->load->model('coreapp/card_model');
		
		$input = $this->input;
		$core = $this->core;
		
		$limitseqno = $input->post('limitseqno', TRUE);
		$brseqno = $core->getBranchID();
		$ipAddress = $core->getIPAddress();
		$workstation = $core->getWorkstation();
		$userAudit = $core->getUserID();
		$override = '';
		$sessionID = $core->getSessionID();
		
		$result = $this->card_model->deleteDefaultOnlineLimit(
			$limitseqno,
			$brseqno,
			$ipAddress,
			$workstation,
			$userAudit,
			$override,
			$sessionID
		);
		
		$row = $result->row_array();
		
		if (intval($row['errno']) > 0) {
			$success = FALSE;
		} else {
			$success = TRUE;
		}
		
		$message = $row['errmsg'];
		
		$result->free_result();
		$result->next_result();
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
}