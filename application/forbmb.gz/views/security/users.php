<form id="userListForm" method="post">
<div style="width:1000px">
	<h1>User List</h1>
    <table class="dataTable">
        <thead>
            <tr>
                <th width="80">User ID</th>
                <th width="140">Name</th>
                <th>Branch</th>
                <th>User Group</th>
                <th>Status</th>
                <th width="150">Last Login Date</th>
                <th width="150">Last Password Change</th>
                <th width="150">Date Created</th>
                <th>grpseqno</th>
                <th>position</th>
                <th>xml1</th>
                <th>department</th>
                <th>tmseqno</th>
                <th>allows</th>
                <th>brseqno</th>
                <th>enabledisable</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<div id="bottom">
	<span class="buttons floatLeft">
    	<button id="addBtn">Add</button
        ><button id="modifyBtn" disabled>Modify</button
        ><button id="deleteBtn" disabled>Delete</button
        ><button id="disableBtn" disabled>Disable</button
        ><button id="enableBtn" disabled class="hidden">Enable</button
        ><button id="resetSettingsBtn" disabled>Reset Settings</button
        ><button id="resetPwdBtn" disabled>Reset Password</button>
	</span>
    <span class="buttons floatRight">
    	<button id="refreshBtn">Refresh</button
        ><button class="closebtn">Close</button>
	</span>
</div>
</form>
<div id="customToolbar" class="hidden">
    <div class="top">
        <!--<div class="dataTables_custom floatLeft"><span class="info"></span></div>-->
        <div class="dataTables_custom floatLeft" style="padding:0 !important">
        	<span class="info">
        		Branch:
                <select id="branchList" style="width:150px">
                	<option value="0">ALL</option>
					<?php echo html_entity_decode($branches); ?>
                </select>
			</span>
            <span class="info">
        		Group:
                <select id="groupList" style="width:150px">
                	<option value="0">ALL</option>
					<?php echo html_entity_decode($usergroups); ?>
                </select>
			</span>
		</div>
    </div>
</div>
<style>
.dataTables_scrollBody {
	min-height: 200px !important;
	max-height: 250px !important;
}
</style>

<script>
$(function() {
	//init vars
	var loading = '<img src="images/loader.gif" width="16" height="18" alt="loading" title="loading"/>Retrieving user list...',
		error = '<img src="images/error.gif" width="7" height="19" alt="error" title="error" /> Error: ';
	
	var addBtn = '#addBtn',
		modifyBtn = '#modifyBtn',
		deleteBtn = '#deleteBtn',
		disableBtn = '#disableBtn',
		enableBtn = '#enableBtn',
		resetSettingsBtn = '#resetSettingsBtn',
		resetPwdBtn = '#resetPwdBtn',
		refreshBtn	= '#refreshBtn',
		//status = '#status',
		branch = '#branchList',
		usergroup = '#groupList',
		form = $('form'),
		user = {},
		jqxhr = null;
	
	var buttons = modifyBtn + ',' + deleteBtn + ',' + disableBtn + ',' + enableBtn + ',' + resetSettingsBtn + ',' + resetPwdBtn;
	//end
	
	oTable = $(DATATABLE).dataTable({
		bRetrieve: true,
		bJQueryUI: true,
		aLengthMenu: DTLENGTHMENU,
		aaSorting: [],
		aoColumns: ([
			null,//user.ID
			null,//userName
			null,//branch
			null,//group
			null,//status
			null,//last login
			null,//last pwd change
			null,//dtcreated
			{'bVisible': false },//grpseqno
			{'bVisible': false },//position
			{'bVisible': false },//xml1
			{'bVisible': false },//department
			{'bVisible': false },//tmseqno
			{'bVisible': false },//allows
			{'bVisible': false },//brseqno
			{'bVisible': false } //enabledisable
		]),
		sScrollY: '100%',
		sScrollX: '100%', // Required for viewing tables with lots of columns at low resolution - otherwise columns are mis-aligned
		sPaginationType: 'full_numbers',
		fnRowCallback: function(nRow, aData, iDisplayIndex) {
			$(nRow).attr('id', aData[0]).unbind('click dblclick').click(function () {
				//close dialog boxes		
				if ($(MSGBOX).length > 0) {
					$(MSGBOX).dialog('close');
				}
				
				//highlight rows
				$('tbody tr').removeClass('rowSelected');
                $(this).addClass('rowSelected');
				
				//set temp var
				user = {
					ID: aData[0],
					name: aData[1],
					grpdesc: aData[3],
					status: aData[4],
					dtCreated: aData[7],
					grpseqno: aData[8],
					position: aData[9],
					xml1: aData[10],
					department: aData[11],
					tmseqno: aData[12],
					allows: aData[13],
					brseqno: aData[14]
				}
				
				//
				if (user.status === 'Disabled') {
					$(enableBtn).show();
					$(disableBtn).hide();
				} else {
					$(enableBtn).hide();
					$(disableBtn).show();
				}
				
				if (aData[14] === '1') {
					$(enableBtn + ',' + disableBtn).removeAttr('disabled');
				}
				$(buttons).removeAttr('disabled');
			}).dblclick(function () {
                $(modifyBtn).trigger('click');
            });
			
			//alert(buttons + ',' + enableBtn + ',' + disableBtn);
			//$(buttons + ',' + enableBtn + ',' + disableBtn).attr('disabled', true);
			$('tbody tr').removeClass('rowSelected');
			$(buttons + ',' + enableBtn + ',' + disableBtn).attr('disabled', true);
			return nRow;
		}
	});
	
	getData(<?php echo $initgrpseqno; ?>, <?php echo $initbrseqno; ?>, 0);
	<?php echo $uiToolbar; ?>
	
	//default Action
	/*$(TABCONTENT).hide(); //hide all content
	$(TABS).first().addClass('active').show(); //activate first tab
	$(TABCONTENT).first().show(); //show first tab content*/
	       			
	//onClick Event
	/*$(TABS).click(function() {
		if (!$(this).hasClass('active')) {
			$(WRAPPER).height('auto');
			
			$(TABS).removeClass('active'); //remove any "active" class
			var that = $(this);
			that.addClass('active'); //add "active" class to selected tab
			
			var x = $(TABSActive).find('a');
			
			var activeTab = x.attr('href'); //find the rel attribute value to identify the active tab + content
			var grpseqno = x.attr('grpseqno');
			var index = x.attr('tableIndex');
			
			var brseqno = $(branch).val();
			getData(grpseqno, brseqno, index);
			
			$(status).html(loading).show();				
			jqxhr.error(function() {

			}).success(function() {
				$(TABS).removeClass('active'); //remove any "active" class
				that.addClass('active'); //add "active" class to selected tab
			
				$(TABCONTENT).hide(); //hide all tab content
				$(activeTab).show(); //fade in the active content
				oTable.fnAdjustColumnSizing(); //fix misaligned columns
			});
		}
		return false;
	});*/
	
	function getData(grpseqno, brseqno, cache) {
		cache = typeof(cache) != 'undefined' ? cache : 1;
		abortAJAXRequests();
		//serialize AJAX request
		requests.push(
			jqxhr = $.ajax({
				type: 'POST',
				url: 'security/users/getData',				
				data: {
					grpseqno: grpseqno,
					brseqno: brseqno,
					cache: cache
				},
				dataType: 'json',
				/*error: function(jqXHR, textStatus, errorThrown) {
					if (jqXHR.status !== 0) {
						$(status).html(error + '(' + textStatus + ')').show();
					}
				},*/
				beforeSend: function () {
					waitMessage('Retrieving user list...');
				},
				success: function(data) {
					$.fn.dataTableExt.iApiIndex = 0;
					oTable.fnClearTable(0);
					oTable.fnAddData(data['details']);
					oTable.fnDraw();
							
					//$(status).html('').hide();
				},
				complete: function() {
					if ($(MSGBOX).length > 0) {
						$(MSGBOX).dialog('close');
					}
				}
			})
		);
	}
	
	$(addBtn).click(function(e) {
		//var grpseqno = $(TABS+'.active a').attr('grpseqno');
		//window.location.hash = 'security/usernew/' + grpseqno;
		//var grpseqno = $(usergroup).val();
		window.location.hash = 'security/usernew/';
		e.preventDefault();
	});

	$(DATATABLE).find('tbody tr').die().live('dblclick', function() {
		//if record count > 0
		if (oTable.fnSettings().fnRecordsDisplay() > 0) {
			$(modifyBtn).trigger('click');
		}
	});
	
	$(modifyBtn).click(function(e) {
		if (user) {
			requests.push(
				$.ajax({
					type: 'POST',
					url: 'security/users/cache',
					data: user,
					dataType: 'json',
					success: function(data) {
						if (data.success === true) {
							window.location.hash = 'security/useredit';
						}
					}
				})
			)
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(deleteBtn).click(function(e) {
		if (user) {
			messageBox('Delete User ID <strong>['+ user.ID +']</strong>?','Confirm','confirm',function() {
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'security/users/delete',
						data: {
							userID: user.ID
						},
						dataType: 'json',
						beforeSend: function() {
							waitMessage('Deleting User ID <strong>['+ user.ID +']</strong>...');
						},
						success: function(data) {
							if (data.removed === true) {
								messageBox('User ID <strong>['+ user.ID +']</strong> deleted successfully');
								oTable.fnDeleteRow(oTable.fnGetPosition($('#' + user.ID)[0]));
								$(buttons + ',' + enableBtn + ',' + disableBtn).attr('disabled', true);
							}
						}
					})
				);
			});
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(disableBtn).click(function(e) {
		if (user) {			
			messageBox('Disable User ID <strong>['+ user.ID +']</strong>?','Confirm','confirm',function() {
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'security/users/disable',
						data: {
							userID: user.ID
						},
						dataType: 'json',
						beforeSend: function() {
							waitMessage('Disabling User ID <strong>['+ user.ID +']</strong>...');
						},
						success: function(data) {
							if (data['disabled'] === true) {
								messageBox('User ID <strong>['+ user.ID +']</strong> has been disabled');
								oTable.fnUpdate(data['newStat'], oTable.fnGetPosition($('#' + user.ID)[0]), 4, false);
								$(refreshBtn).trigger('click');
							}
						}
					})
				);
			});
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(enableBtn).click(function(e) {
		if (user) {			
			messageBox('Enable User ID <strong>['+ user.ID +']</strong>?','Confirm','confirm',function() {
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'security/users/enable',
						data: {
							userID: user.ID
						},
						dataType: 'json',
						beforeSend: function() {
							waitMessage('Enabling User ID <strong>['+ user.ID +']</strong>...');
						},
						success: function(data) {
							if (data['enabled'] === true) {
								messageBox('User ID <strong>['+ user.ID +']</strong> has been enabled');
								oTable.fnUpdate(data['newStat'], oTable.fnGetPosition($('#' + user.ID)[0]), 4, false);
								$(refreshBtn).trigger('click');
							}
						}
					})
				);
			});
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(resetSettingsBtn).click(function(e) {
		if (user) {			
			messageBox('Reset User ID <strong>['+ user.ID +']</strong>?','Confirm','confirm',function() {
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'security/users/resetSettings',
						data: {
							userID: user.ID
						},
						dataType: 'json',
						beforeSend: function() {
							waitMessage('Resetting User ID <strong>['+ user.ID +']</strong>...');
						},
						success: function(data) {
							if (data['resetSettings'] === true) {
								messageBox('User ID <strong>['+ user.ID +']</strong> reset');
								oTable.fnUpdate(data['newStat'], oTable.fnGetPosition($('#' + user.ID)[0]), 4, false);
							}
						}
					})
				);
			});
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(resetPwdBtn).click(function(e) {
		if (user) {		
			messageBox('Reset password for User ID <strong>['+ user.ID +']</strong>?','Confirm','confirm',function() {
				requests.push(
					$.ajax({
						type: 'POST',
						url: 'security/users/resetPwd',
						data: {
							userID: user.ID
						},
						dataType: 'json',
						beforeSend: function() {
							waitMessage('Resetting <strong>['+ user.ID +']</strong> password...');
						},
						success: function(data) {
							if (data['resetPwd'] === true) {
								messageBox('User ID <strong>['+ user.ID +']</strong> password reset');
								oTable.fnUpdate(data['newStat'], oTable.fnGetPosition($('#' + user.ID)[0]), 4, false);
							}
						}
					})
				);
			});
		} else {
			messageBox('Please select a user from the list');
		}
		e.preventDefault();
	});
	
	$(refreshBtn).click(function(e) {
		//display status indicator
		//$(status).html(loading).show();	
		
		var a = $(TABS + '.active a');
		grpseqno = a.attr('grpseqno');
		index = a.attr('tableIndex');
		
		var brseqno = $(branch).val();
		getData(grpseqno, brseqno, index, 0);
		
		e.preventDefault();
	});
	
	//filter by branch
	$(branch).change(filterData);
	//filter by user group
	$(usergroup).change(filterData);
	
	function filterData()
	{
		//display status indicator
		//$(status).html(loading).show();	
		
		var grpseqno = $(usergroup).val();
		var brseqno = $(branch).val();
		getData(grpseqno, brseqno, 0);
	}
});
</script>