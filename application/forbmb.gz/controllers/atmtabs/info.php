<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Info extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(MONATM_NO);
	}
	
	function index()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coreapp/area_model');
		$this->load->model('coresys/atm_model');
		$this->load->library('shortxml');
		
		$atm   = $this->atm_model;
		$core  = $this->core;
		$input = $this->input;
		$xml   = $this->shortxml;
		
		//for ATM list
		if ($input->get('list', TRUE) === '1') {
			if ($core->canMon()) {
				$branchCode = $input->get('brcode');
				$locCode = $input->get('loccode');
			} else {
				$branchCode = $core->getBranchCode();
				$locCode = 0;
			}
			$status = $input->get('status');
			
			//get ATM list
			$result  = $atm->getATMList($branchCode, $locCode, $status);	
			$atmList = $core->showATMList($result);
			$atmList = $core->compressOutput($atmList);
			
			$result->free_result();
			$result->next_result();
		} else {
			$atmList = NULL;
		}
		//end
		
		//get ATM Info
		
		$terminalCode = $input->get('terminalcode');
		
		$result	= $atm->getATMInfoByCode($terminalCode);
		$row 	= $result->row_array();
		$xml->setXML($row['xml']);
			
		$terminalCode  = $row['termcode'];
		$terminalID    = $row['termid'];
		$terminalLuno  = $row['luno'];
		$terminalStats = $row['statdesc'] ? $row['statdesc'] : $row['status'] .'-Unknown';
		$terminalDesc  = $row['description'];
		$installType   = $row['insttype'];
		$terminalLoc   = ucwords(strtolower($row['location']));
		//$contactNo	   = $xml->getValue('CONTACT') ? $xml->getValue('CONTACT') : 'None';
		$lastCmd	   = $row['cmdstat'] ? str_replace('Atm', 'ATM', ucwords(strtolower($row['cmdstat']))) : 'Unknown';
		$cmdStatus	   = $row['cmddesc'];
		$brCode		   = $row['brcode'];
		
		//get area name
		$res = $this->area_model->getAreaByBranch($brCode);
		$rw  = $res->row_array();
		
		$areaName = ucwords(strtolower($rw['areaname']));//$core->getAreaName();
		
		$res->free_result();
		$res->next_result();
		//end
		
		if ($core->canMon()) {
			if (!$branches = $this->cache->get($this->core->getSessionID() . 'branches')) {
				$this->load->model('coreapp/branch_model');
				$result = $this->branch_model->getBranchList();
			
				$branches = $result->result_array();
				
				$result->free_result();
				$result->next_result();
				$this->cache->save($this->core->getSessionID() .'branches', $branches, CACHE_TTL);
			}
			
			$branchName = NULL;
			foreach ($branches as $row) {
				if ($brCode == $row['brcode']) {
					$branchName = ucwords(strtolower($row['brname']));
					break;
				}
			}
		} else {
			$branchName = $core->getBranchName();
		}
		
		$details = $core->compressOutput('<table>
			<tr>
				<td class="idName" width="150">Terminal Code:</td>
				<td id="infoTerminalCode" class="idNumber" width="200">'. $terminalCode .'</td>
				<td width="150" class="label">LUNO:</td>
				<td id="infoTerminalLuno" width="200">'. $terminalLuno .'</td>
			</tr>
			<tr>
				<td class="label">Terminal ID:</td>
				<td id="infoTerminalID">'. $terminalID .'</td>
				<td class="label">Terminal Status:</td>
				<td id="infoTerminalStats">'. $terminalStats .'</td>
			</tr>
			<tr>
				<td class="label">Description:</td>
				<td id="infoTerminalDesc">'. $terminalDesc .'</td>
				<td class="label">Installation Type:</td>
				<td id="infoInstallType">'. $installType .'</td>
			</tr>
			<tr>
				<td class="label">Location:</td>
				<td colspan="3" id="infoTerminalLoc">'. $terminalLoc .'</td>
			</tr>
			<tr>
				<td class="label">Area:</td>
				<td colspan="3" id="infoTerminalArea">'. $areaName .'</td>
			</tr>
			<tr>
				<td class="label">Branch:</td>
				<td colspan="3" id="infoTerminalBranch">'. $branchName .'</td>
			</tr>
			<tr>
				<td class="label">Last Command:</td>
				<td id="infoLastCommand">'. $lastCmd .'</td>
				<td class="label">Command Status:</td>
				<td id="infoCommandStatus">'. $cmdStatus .'</td>
			</tr>
		</table>');
		
		//<td class="label">Branch:</td>
				//<td id="infoTerminalBranch">'. $branchName .'</td>
				
       	echo json_encode(array(
			'success' => TRUE,
			'atm' 	  => $atmList,
			'details' => $details
		));
	}
}
/* End of file info.php */
/* Location: ./application/contollers/atmtabs/info.php */