<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ResetLimits extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(CARDINFO);
	}
	
	function index()
	{
		$this->load->view('card/resetlimits');
	}
}