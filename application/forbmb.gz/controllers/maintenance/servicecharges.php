<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ServiceCharges extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(SVCCHARGES_NO);
	}
	
	function index()
	{
		$this->load->model('coresys/misc_model');
		
		$brcode = $this->core->getBranchCode();
		
		$result = $this->misc_model->getTermListForFeeList($brcode);
		
		$data['termList'] = '<option value="zzzz">zzzz - GLOBAL</option>';
		
		if ($result->num_rows() > 0) {
			foreach ($result->result_array() as $row) {
				$data['termList'] .= '<option value="'. $row['termcode'] .'">'. $row['termcode'] .' - '. $row['description'] .'</option>';
			}
		}

		$result->free_result();
		$result->next_result();
		
		$this->load->view('maintenance/servicecharges', $data);
	}
	
	function getData()
	{
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->model('coresys/misc_model');
		$this->load->library('shortxml');
		
		$xml = $this->shortxml;
		
		$termCode = $this->input->get('termCode', TRUE);
		
		$result = $this->misc_model->getFeeList($termCode);
		
		$details = array();
		$resultArr = $result->result_array();
		if ($result->num_rows() > 0) {
			foreach ($resultArr as $row) {
				
				$brseqno = $row['brseqno'];
				
				$xml->setXML($row['servdesc']);
				
				if ($row['brseqno'] === '9999') {
					$branch = '(Global)';
				} else {
					//branches
					if (!$branches = $this->cache->get($this->core->getSessionID() . 'branches')) {
						$this->load->model('coreapp/branch_model');
						$result = $this->branch_model->getBranchList();
					
						$branches = $result->result_array();
						$this->cache->save($this->core->getSessionID() .'branches', $branches, CACHE_TTL);
					}
		
					foreach ($branches as $b) {
						if ($brseqno == $b['brseqno']) {
							$branch = $b['brname'];
							break;
						}
					}
					$result->free_result();
					$result->next_result();
				}
				
				$details[] = array(
					//hidden
					$row['feeseqno'],
					$brseqno,
					$row['servtype'],
					$row['feetype'],
					$row['authname'],
					$row['nettype'],
					$row['chargetype'],
					$row['trxcode2'],
					//visible
					$row['mnemonic'],
					$branch,
					$this->core->currency($row['feeval']),
					$row['termtype'],
					$xml->getValue('DESC'),
					$row['netdesc'],
					$row['trandesc'],
					$row['feetypedesc'],
					$row['chargedesc'],
					$this->core->currency($row['minrange']),
					$this->core->currency($row['maxrange']),
					$row['description']
				);
			}
		}
		
		$result->free_result();
		$result->next_result();
		
		echo json_encode(array(
			'success' => TRUE,
			'details' => $details
		));
	}
	
	function cache()
	{
		$_SESSION['serviceCharge'] = $_POST;
		
		echo json_encode(array(
			'success' => TRUE
		));
	}
	
	function delete()
	{
		$this->load->model('coresys/misc_model');
		
		$core = $this->core;
		
		$feeseqno = $this->input->post('feeseqno', TRUE);
		$brseqno = $core->getBranchID();
		$ipAddress = $core->getIPAddress();
		$workstation = $core->getWorkstation();
		$userID = $core->getUserID();
		$override = '';
		
		$result = $this->misc_model->deleteFee(
			$feeseqno,
			$brseqno,
			$ipAddress,
			$workstation,
			$userID,
			$override
		);
		
		$success = TRUE;
		$message = 'Service Charge removed successfully';
		
		$row = $result->row_array();
		
		if ($row['errno'] > 0) {
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		$result->free_result();
		$result->next_result();
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message
		));
	}
}