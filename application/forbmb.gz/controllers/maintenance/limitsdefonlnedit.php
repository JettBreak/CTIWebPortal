<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class LimitsDefOnlnEdit extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(CARDINFO);
	}
	
	function index()
	{
		$this->load->model('coreapp/card_model');
		
		$info = $_SESSION['onlineLimitsDef'];		
		
		$limitseqno = $info['limitseqno'];
		$trxcode = $info['trxcode'];
		
		$result = $this->card_model->getTransactionAllowsLimit($limitseqno, $trxcode);
		
		$trxList = NULL;
		$inputAttr = NULL;
		$trandesc = NULL;
		foreach ($result->result_array() as $row) {
			
			if ($trxcode === $row['trxcode']) {
				$selected = ' selected';
				$trandesc = $row['description'];
				if ($row['isamtlimit'] === 'N') {
					$inputAttr = ' readonly';
				}
				
			} else {
				$selected = NULL;
			}
			
			$trxList .= '<option value="'. $row['trxcode'] .'" isamtlimit="'. $row['isamtlimit'] .'"'. $selected .'>'. $row['description'] .'</option>';
		}
		
		$data['trxList'] = $trxList;
		$data['trandesc'] = $trandesc;
		$data['inputAttr'] = $inputAttr;
		$data['limitseqno'] = $limitseqno;
		$data['trxcode'] = $info['trxcode'];
		
		$data['cycledef'] = $info['cycledef'];
		$data['cyclemax'] = $info['cyclemax'];
		$data['ctrdef'] = $info['ctrdef'];
		$data['ctrmax'] = $info['ctrmax'];
		$data['tranmindef'] = $info['tranmindef'];
		$data['tranmin'] = $info['tranmin'];
		$data['tranmaxdef'] = $info['tranmaxdef'];
		$data['tranmax'] = $info['tranmax'];
		$data['cycle'] = $info['cycle'];
		$data['duralimit'] = $info['duralimit'];
		$data['nonfeectr'] = $info['nonfeectr'];
		$data['nonfeectrdef'] = $info['nonfeectrdef'];
		$data['nonfeetran'] = $info['nonfeetran'];
		$data['nonfeetrandef'] = $info['nonfeetrandef'];
		$data['nonfeecycle'] = $info['nonfeecycle'];
		
		$data['method'] = 1;
		$data['formAction'] = 'maintenance/limitsdefonln/submit';
		
		$result->free_result();
		$result->next_result();
			
		$this->load->view('maintenance/limitsdefonlnx', $data);
	}
}