<table style="width:100%">
	<thead>
    	<tr>
        	<th>Transactions</th>
            <th>Amount</th>
            <th>Counter</th>
        </tr>
    </thead>
	<tbody>
    </tbody>
</table>