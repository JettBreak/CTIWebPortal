<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ATMNew extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('core');
		$this->core->checkUserAllows(MAINTENANCEATM_NO);
	}
	
	function index()
	{
		$this->load->model('coresys/atm_model');
		$this->load->model('coreapp/area_model');
		
		$atm = $this->atm_model;
		$core = $this->core;	
		
		$data['luno'] 			= NULL;
		$data['dtProd'] = date('m/d/Y');
		$data['screenLoadSize'] = '600';
		$data['otherLoadSize'] 	= '600';
		$data['stateLoadSize'] 	= '600';
		$data['maxNotes'] 		= '40';
		$data['fitLoadSize'] 	= '600';
		$data['dispenseLogic'] 	= '600';
		$data['optLoadSize'] 	= '600';
		
		$data['loadNewKey'] = NULL;
		$data['loadPower']  = NULL;
			
		$data['threshold'] = '0.00';
		$data['decimal'] = '2';
		$data['status'] = 'Out of Service';
		
		//product codes
		$result = $atm->getProductCodes();
		
		$data['prodName'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['prodName'] .= '<option value="'. $row['productcode'] .'">'. $row['productname'] .'</option>';
		}
		
		//terminal language
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getTerminalLanguage();
		
		$data['termLang'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['termLang'] .= '<option value="'. $row['termlang'] .'">'. $row['description'] .'</option>';
		}
		
		//location
		$result->free_result();
		$result->next_result();
		
		if ($core->isHeadOffice()) {
			$result = $atm->getAllLocations();
		} else {
			$result = $atm->getLocations($core->getBranchCode());
		}
		
		$resultArr = $result->result_array();
		$numRows = $result->num_rows();
		
		$result->free_result();
		$result->next_result();
		
		$data['location'] = NULL;
		$areaName = 'N/A';
		$brchName = 'N/A';
		
		if ($numRows > 0) {
			foreach ($resultArr as $row) {
				$result = $this->area_model->getAreaByBranch($row['brcode']);
				$r = $result->row_array();
				
				if ($areaName === 'N/A') {
					$areaName = $r['areaname'];
				}
				
				if ($brchName === 'N/A') {
					$brchName = $r['brname'];
				}
				
				$area = $r['areaname'] ? $r['areaname'] : 'Undefined';
				$branch = $r['brname'] ? $r['brname'] : 'Undefined';
	
				$data['location'] .= '<option value="'. $row['loccode'] .'" areaname="'. $area .'" brname="'. $branch .'">'. $row['location'] .'</option>';
				
				$result->free_result();
				$result->next_result();
			}
		} else {
			$data['location'] .= '<option value="">No Location Defined</option>';
		}
		
		//Area and Branch
		$data['areaName'] = $areaName;
		$data['branchName'] = $brchName;
		//end
		
		//emulation
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getCodeList('TERMEMUL');
		
		$data['emulation'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['emulation'] .= '<option value="'. $row['codevalue'] .'">'. $row['xml1'] .'</option>';
		}
			
		//program codes
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getProgramCodes();
		
		$row = $result->row_array();
		$data['progCodex'] = $row['progcode'];
		$data['progLangx'] = $row['proglang'];
		
		$data['progName'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['progName'] .= '<option proglang="'. $row['proglang'] .'" value="'. $row['progcode'] .'">'. $row['tpfile'] .'</option>';
		}
		
		//installation type
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getCodeList('INSTTYPE');
		
		$data['instType'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['instType'] .= '<option value="'. $row['codeseqno'] .'">'. $row['codevalue'] .'</option>';
		}
		
		//dispense logic
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getCodeList('DISPLOGIC');
		
		$data['dispLogic'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['dispLogic'] .= '<option value="'. $row['codeseqno'] .'">'. $row['codevalue'] .'</option>';
		}
		
		//denominations
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getDenomination();
		
		$data['progCodeDeno'] = NULL;
		foreach ($result->result_array() as $row) {
			$data['progCodeDeno'] .= '<option value="'. $row['progcode'] .'">'. $row['progcode'] .'</option>';
		}
		$data['progLangDeno'] = '0';
		
		$result->free_result();
		$result->next_result();
		
		$result = $atm->getTerminalDenomination($data['progCodex'], $data['progLangx']);
		
		$data['denominations'] = NULL;
		foreach ($result->result_array() as $row) {
			$parmData = $row['parmdata'];
			
			$curr = substr($parmData, 0, 3);
			$deno = $core->currency(substr($parmData, 6, 12) / 100);
			$cass = substr($parmData, 4, 1);
			$data['denominations'] .= '<tr>
				<td>'. $curr .'</td>
				<td>'. $deno .'</td>
				<td>'. $cass .'</td>
			</tr>';
		}
				
		//default currency
		$result->free_result();
		$result->next_result();
			
		$result = $atm->getCurrency();
		
		$data['currency'] = NULL;
		foreach ($result->result_array() as $row) {
			$selected = ($row['currency'] === 'PHP' ? ' selected' : NULL);
			$data['currency'] .= '<option value="'. $row['currency'] .'"'. $selected .'>'. $row['currency'] .'</option>';
		}
		
		//contact persons
		$data['hName'] = NULL;
		$data['hTel'] = NULL;
		$data['hNameAttr'] = NULL;
		$data['hTelAttr'] = NULL;
		$data['nName'] = NULL;
		$data['nTel'] = NULL;
		$data['nNameAttr'] = NULL;
		$data['nTelAttr'] = NULL;
		$data['tName'] = NULL;
		$data['tTel'] = NULL;
		$data['tNameAttr'] = NULL;
		$data['tTelAttr'] = NULL;
		$data['oName'] = NULL;
		$data['oTel'] = NULL;
		$data['oNameAttr'] = NULL;
		$data['oTelAttr'] = NULL;
		
		$data['header'] = 'New ATM Entry';
		$data['termCodeParams'] = 'class="validate[required] numbersOnly" maxlength="8"';
		$data['termID'] = NULL;
		$data['desc'] = NULL;
		$data['contactNo'] = NULL;
		$data['termIDParams'] = 'class="validate[required]"';
		$data['submitBtnVal'] = 'maintenance/atmnew/submit';
		$data['waitMsg'] = 'Sending new ATM entry...';
		$data['submitBtnMsg'] = 'Submit new ATM entry?';
		
		$this->load->view('maintenance/atmx', $data);
	}
	
	function submit()
	{
		$this->load->model('coreapp/user_model');
		
		$core  = $this->core;
		$input = $this->input;
		
		$userAudit = $core->getUserID();
		$sessionID = $core->getSessionID();
		
		$row = $this
			->user_model
			->checkLogin($userAudit, $sessionID)
			->row_array();
		
		if ($row['errno'] !== '8') { //if session valid
			$termCode 		= $input->post('termCode', TRUE);
			$termID 		= $input->post('termID', TRUE);
			$luno 			= $input->post('luno', TRUE);
			$instType 		= $input->post('instType', TRUE);
			$codeDeno 		= $input->post('progCodeDeno', TRUE);
			$langDeno 		= $input->post('progLangDeno', TRUE);
			$emulation 		= $input->post('emulation', TRUE);
			$prodCode 		= $input->post('prodName', TRUE);
			$locCode 		= $input->post('location', TRUE);
			$description 	= $input->post('description', TRUE);
			$amtdec			= $input->post('decimal', TRUE);
			$progCode 		= $input->post('progCode', TRUE);
			$progLang 		= $input->post('progLang', TRUE);
			$termLang 		= $input->post('termLang', TRUE);
			$screenLoadSize = $input->post('screenLoadSize', TRUE);
			$stateLoadSize 	= $input->post('stateLoadSize', TRUE);
			$fitLoadSize 	= $input->post('fitLoadSize', TRUE);
			$optLoadSize 	= $input->post('optLoadSize', TRUE);
			$otherLoadSize 	= $input->post('otherLoadSize', TRUE);
			$isLoadKeyNew 	= $input->post('loadNewKey') ? '1' : '0';
			$dispLogic 		= $input->post('dispenseLogic', TRUE);
			$isLoadPower 	= $input->post('loadPower') ? '1' : '0';
			$dtProd			= $input->post('dtProd', TRUE) === 'Undefined' ? NULL : $core->formatDate('Y-m-d', $input->post('dtProd', TRUE));
			
			$xml1 			= '<CURRENCY>'. $input->post('currency', TRUE) .'</>'.
								'<THRES>'. str_replace(',', '', $input->post('threshold', TRUE)) .'</>'.
								 '<HNAME>'. $input->post('hName', TRUE) .'</>'.
								 '<HTEL>'. $input->post('hTel', TRUE) .'</>'.
								 '<NNAME>'. $input->post('nName', TRUE) .'</>'.
								 '<NTEL>'. $input->post('nTel', TRUE) .'</>'.
								 '<TNAME>'. $input->post('tName', TRUE) .'</>'.
								 '<TTEL>'. $input->post('tTel', TRUE) .'</>'.
								 '<ONAME>'. $input->post('oName', TRUE) .'</>'.
								 '<OTEL>'. $input->post('oTel', TRUE) .'</>';
								 
			$xml2 			= '<MAXNOTES>'. $input->post('maxNotes', TRUE) .'</>';
			
			$this->load->model('coresys/atm_model');
			
			$result = $this->atm_model->insertATMTerminal(
				$termCode, $termID, $luno, $instType, $codeDeno, $langDeno, $emulation, $prodCode,
				$locCode, $description, $amtdec, $progCode, $progLang, $termLang, $screenLoadSize, $stateLoadSize,
				$fitLoadSize, $optLoadSize, $otherLoadSize, $isLoadKeyNew, $dispLogic, $isLoadPower, $dtProd, $xml1, $xml2
			);
			
			$row = $result->row_array();
			
			if ($row['errno'] === '0') {
				$success = TRUE;
				$message = 'New ATM entry saved';
			} else {
				$success = FALSE;
				$message = $row['errmsg'];
			}
		} else { //if invalid userID / session then logout
			$success = FALSE;
			$message = $row['errmsg'];
		}
		
		echo json_encode(array(
			'success' => $success,
			'message' => $message,
			'errorno' => $row['errno']
		));
	}
}
/* End of file atmnew.php */
/* Location: ./application/contollers/maintenance/atmnew.php */